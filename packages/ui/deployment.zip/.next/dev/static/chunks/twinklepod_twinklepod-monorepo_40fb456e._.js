(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StoryReaderPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/packages/ui/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$contexts$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/packages/ui/contexts/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$contexts$2f$ChildContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/packages/ui/contexts/ChildContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/packages/ui/components/ui/Button.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function StoryReaderPage() {
    _s();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$contexts$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const { selectedChild } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$contexts$2f$ChildContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChild"])();
    const [story, setStory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [isFavorite, setIsFavorite] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [progress, setProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const contentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StoryReaderPage.useEffect": ()=>{
            fetchStory();
        }
    }["StoryReaderPage.useEffect"], [
        params.id
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StoryReaderPage.useEffect": ()=>{
            const interval = setInterval(saveProgress, 10000);
            return ({
                "StoryReaderPage.useEffect": ()=>clearInterval(interval)
            })["StoryReaderPage.useEffect"];
        }
    }["StoryReaderPage.useEffect"], [
        progress,
        selectedChild
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StoryReaderPage.useEffect": ()=>{
            const handleScroll = {
                "StoryReaderPage.useEffect.handleScroll": ()=>{
                    if (!contentRef.current) return;
                    const { scrollTop, scrollHeight, clientHeight } = contentRef.current;
                    const scrolled = scrollTop / (scrollHeight - clientHeight) * 100;
                    setProgress(Math.min(Math.round(scrolled), 100));
                }
            }["StoryReaderPage.useEffect.handleScroll"];
            const ref = contentRef.current;
            ref?.addEventListener('scroll', handleScroll);
            return ({
                "StoryReaderPage.useEffect": ()=>ref?.removeEventListener('scroll', handleScroll)
            })["StoryReaderPage.useEffect"];
        }
    }["StoryReaderPage.useEffect"], []);
    const fetchStory = async ()=>{
        try {
            const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].get(`/stories/${params.id}`);
            const storyResponse = await fetch(data.s3_url);
            const storyData = await storyResponse.json();
            setStory(storyData);
            if (user && selectedChild) {
                await __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].post('/api/interaction', {
                    child_id: selectedChild.child_id,
                    story_id: params.id,
                    event_type: 'view'
                });
            }
        } catch (error) {
            console.error('Failed to fetch story:', error);
        } finally{
            setLoading(false);
        }
    };
    const saveProgress = async ()=>{
        if (!user || !selectedChild || !story) return;
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].post('/api/progress', {
                child_id: selectedChild.child_id,
                story_id: story.story_id,
                paragraph_index: Math.floor(progress / 100 * story.text.length),
                percentage: progress,
                completed: progress >= 95
            });
        } catch (error) {
            console.error('Failed to save progress:', error);
        }
    };
    const toggleFavorite = async ()=>{
        if (!user || !selectedChild || !story) return;
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].post('/api/interaction', {
                child_id: selectedChild.child_id,
                story_id: story.story_id,
                event_type: isFavorite ? 'unfavorite' : 'favorite'
            });
            setIsFavorite(!isFavorite);
        } catch (error) {
            console.error('Failed to toggle favorite:', error);
        }
    };
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-4xl mx-auto px-4 py-12 text-center",
            children: "Loading story..."
        }, void 0, false, {
            fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
            lineNumber: 106,
            columnNumber: 12
        }, this);
    }
    if (!story) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-4xl mx-auto px-4 py-12 text-center",
            children: "Story not found"
        }, void 0, false, {
            fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
            lineNumber: 110,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-4xl mx-auto px-4 py-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6 flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>router.back(),
                        variant: "outline",
                        children: "← Back"
                    }, void 0, false, {
                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this),
                    user && selectedChild && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: toggleFavorite,
                        variant: isFavorite ? 'primary' : 'outline',
                        children: [
                            isFavorite ? '★' : '☆',
                            " Favorite"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                        lineNumber: 118,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                lineNumber: 115,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-lg shadow-lg p-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-4xl font-bold mb-4",
                        children: story.title
                    }, void 0, false, {
                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                        lineNumber: 125,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-4 text-sm text-gray-600 mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "Age ",
                                    story.age_range
                                ]
                            }, void 0, true, {
                                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                lineNumber: 127,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "•"
                            }, void 0, false, {
                                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                lineNumber: 128,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    story.duration_minutes,
                                    " min read"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                lineNumber: 129,
                                columnNumber: 11
                            }, this),
                            story.moral && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "•"
                                    }, void 0, false, {
                                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                        lineNumber: 132,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: story.moral
                                    }, void 0, false, {
                                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                        lineNumber: 133,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this),
                    user && selectedChild && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between text-sm mb-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Progress"
                                    }, void 0, false, {
                                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                        lineNumber: 141,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            progress,
                                            "%"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                        lineNumber: 142,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                lineNumber: 140,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full bg-gray-200 rounded-full h-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-purple-600 h-2 rounded-full",
                                    style: {
                                        width: `${progress}%`
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                    lineNumber: 145,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                lineNumber: 144,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                        lineNumber: 139,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: contentRef,
                        className: "prose max-w-none overflow-y-auto max-h-[600px]",
                        children: story.text.map((paragraph, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mb-4 text-lg leading-relaxed",
                                        children: paragraph
                                    }, void 0, false, {
                                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                        lineNumber: 153,
                                        columnNumber: 15
                                    }, this),
                                    story.image_positions.includes(index) && story.images[story.image_positions.indexOf(index)] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "my-6 bg-gray-100 rounded-lg h-64 flex items-center justify-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-400",
                                            children: [
                                                "Image ",
                                                story.image_positions.indexOf(index) + 1
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                            lineNumber: 156,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                        lineNumber: 155,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                                lineNumber: 152,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                        lineNumber: 150,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
                lineNumber: 124,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/[id]/page.tsx",
        lineNumber: 114,
        columnNumber: 5
    }, this);
}
_s(StoryReaderPage, "0jZoWpM9xztUsrfana2PQvqYfAU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$contexts$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$contexts$2f$ChildContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChild"]
    ];
});
_c = StoryReaderPage;
var _c;
__turbopack_context__.k.register(_c, "StoryReaderPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/next/navigation.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/twinklepod/twinklepod-monorepo/node_modules/next/dist/client/components/navigation.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=twinklepod_twinklepod-monorepo_40fb456e._.js.map