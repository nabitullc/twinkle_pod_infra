(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/b5b53_7e121586._.js",
  "static/chunks/twinklepod_twinklepod-monorepo_packages_ui_f0622f57._.js"
],
    source: "dynamic"
});
