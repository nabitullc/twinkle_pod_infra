(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/twinklepod_twinklepod-monorepo_f0fdbe89._.js"
],
    source: "dynamic"
});
