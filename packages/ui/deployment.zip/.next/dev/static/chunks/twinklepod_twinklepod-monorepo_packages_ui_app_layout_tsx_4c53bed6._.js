(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/twinklepod_twinklepod-monorepo_packages_ui_app_globals_8b483be2.css",
  "static/chunks/b5b53_96fa5bac._.js",
  "static/chunks/twinklepod_twinklepod-monorepo_packages_ui_1e91e2ea._.js"
],
    source: "dynamic"
});
