(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/twinklepod_twinklepod-monorepo_packages_ui_f7c7b253._.js"
],
    source: "dynamic"
});
