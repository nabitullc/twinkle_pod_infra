(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/twinklepod/twinklepod-monorepo/packages/ui/components/ui/LoadingSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LoadingSkeleton",
    ()=>LoadingSkeleton,
    "StoryGridSkeleton",
    ()=>StoryGridSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const LoadingSkeleton = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "animate-pulse",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-48 bg-gray-200 rounded-t-lg"
            }, void 0, false, {
                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/components/ui/LoadingSkeleton.tsx",
                lineNumber: 4,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 space-y-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-4 bg-gray-200 rounded w-3/4"
                    }, void 0, false, {
                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/components/ui/LoadingSkeleton.tsx",
                        lineNumber: 6,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-3 bg-gray-200 rounded w-1/2"
                    }, void 0, false, {
                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/components/ui/LoadingSkeleton.tsx",
                        lineNumber: 7,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/components/ui/LoadingSkeleton.tsx",
                lineNumber: 5,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/components/ui/LoadingSkeleton.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = LoadingSkeleton;
const StoryGridSkeleton = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid md:grid-cols-3 lg:grid-cols-4 gap-6",
        children: [
            ...Array(8)
        ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LoadingSkeleton, {}, i, false, {
                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/components/ui/LoadingSkeleton.tsx",
                lineNumber: 17,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)))
    }, void 0, false, {
        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/components/ui/LoadingSkeleton.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c1 = StoryGridSkeleton;
var _c, _c1;
__turbopack_context__.k.register(_c, "LoadingSkeleton");
__turbopack_context__.k.register(_c1, "StoryGridSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StoriesPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/packages/ui/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$components$2f$ui$2f$LoadingSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/packages/ui/components/ui/LoadingSkeleton.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function StoriesPage() {
    _s();
    const [stories, setStories] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [category, setCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StoriesPage.useEffect": ()=>{
            fetchStories();
        }
    }["StoriesPage.useEffect"], [
        category
    ]);
    const fetchStories = async ()=>{
        setLoading(true);
        try {
            const params = category ? {
                category
            } : {};
            const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].get('/stories/list', {
                params
            });
            setStories(data.stories || data);
        } catch (error) {
            console.error('Failed to fetch stories:', error);
            // Mock data for local development
            setStories([
                {
                    story_id: '1',
                    title: 'The Brave Little Rabbit',
                    age_range: '3-8',
                    categories: [
                        'animals',
                        'bedtime'
                    ],
                    duration_minutes: 5,
                    thumbnail_url: ''
                },
                {
                    story_id: '2',
                    title: 'Magic Forest Adventure',
                    age_range: '5-10',
                    categories: [
                        'fantasy',
                        'adventure'
                    ],
                    duration_minutes: 8,
                    thumbnail_url: ''
                },
                {
                    story_id: '3',
                    title: 'The Helpful Elephant',
                    age_range: '3-8',
                    categories: [
                        'animals',
                        'moral'
                    ],
                    duration_minutes: 6,
                    thumbnail_url: ''
                },
                {
                    story_id: '4',
                    title: 'Bedtime in the Stars',
                    age_range: '3-8',
                    categories: [
                        'bedtime',
                        'fantasy'
                    ],
                    duration_minutes: 4,
                    thumbnail_url: ''
                }
            ]);
        } finally{
            setLoading(false);
        }
    };
    const categories = [
        'bedtime',
        'animals',
        'moral',
        'fantasy',
        'short',
        'funny',
        'adventure'
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-7xl mx-auto px-4 py-12",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-4xl font-bold mb-8",
                children: "Browse Stories"
            }, void 0, false, {
                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2 mb-8 overflow-x-auto",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setCategory(''),
                        className: `px-4 py-2 rounded ${!category ? 'bg-purple-600 text-white' : 'bg-gray-200'}`,
                        children: "All"
                    }, void 0, false, {
                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this),
                    categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setCategory(cat),
                            className: `px-4 py-2 rounded capitalize ${category === cat ? 'bg-purple-600 text-white' : 'bg-gray-200'}`,
                            children: cat
                        }, cat, false, {
                            fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                            lineNumber: 60,
                            columnNumber: 11
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$components$2f$ui$2f$LoadingSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoryGridSkeleton"], {}, void 0, false, {
                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                lineNumber: 71,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid md:grid-cols-3 lg:grid-cols-4 gap-6",
                children: stories.map((story)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: `/stories/${story.story_id}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-white rounded-lg shadow hover:shadow-lg transition cursor-pointer",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-48 bg-gray-200 rounded-t-lg"
                                }, void 0, false, {
                                    fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                                    lineNumber: 77,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "p-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "font-bold mb-2",
                                            children: story.title
                                        }, void 0, false, {
                                            fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                                            lineNumber: 79,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex justify-between text-sm text-gray-600",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: [
                                                        "Age ",
                                                        story.age_range
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                                                    lineNumber: 81,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: [
                                                        story.duration_minutes,
                                                        " min"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                                                    lineNumber: 82,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                                            lineNumber: 80,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                                    lineNumber: 78,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                            lineNumber: 76,
                            columnNumber: 15
                        }, this)
                    }, story.story_id, false, {
                        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                        lineNumber: 75,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
                lineNumber: 73,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/twinklepod/twinklepod-monorepo/packages/ui/app/stories/page.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, this);
}
_s(StoriesPage, "vgxoEAxih1akGYag4w3UCiTpyuE=");
_c = StoriesPage;
var _c;
__turbopack_context__.k.register(_c, "StoriesPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=twinklepod_twinklepod-monorepo_packages_ui_f7c7b253._.js.map