(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_605f909f._.js",
  "static/chunks/b5b53_next_dist_compiled_react-dom_cf73a2d2._.js",
  "static/chunks/b5b53_next_dist_compiled_react-server-dom-turbopack_ce64143c._.js",
  "static/chunks/b5b53_next_dist_compiled_next-devtools_index_4baf8617.js",
  "static/chunks/b5b53_next_dist_compiled_d94e2d8a._.js",
  "static/chunks/b5b53_next_dist_client_d1ecf391._.js",
  "static/chunks/b5b53_next_dist_f36b1a7c._.js",
  "static/chunks/b5b53_@swc_helpers_cjs_0a551179._.js"
],
    source: "entry"
});
