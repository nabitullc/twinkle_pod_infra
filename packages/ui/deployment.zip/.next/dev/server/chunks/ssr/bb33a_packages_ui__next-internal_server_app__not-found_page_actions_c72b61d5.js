module.exports = [
"[project]/twinklepod/twinklepod-monorepo/packages/ui/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=bb33a_packages_ui__next-internal_server_app__not-found_page_actions_c72b61d5.js.map