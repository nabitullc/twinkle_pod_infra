module.exports = [
"[project]/twinklepod/twinklepod-monorepo/packages/ui/app/favicon.ico (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.0b3bf435.ico");}),
"[project]/twinklepod/twinklepod-monorepo/packages/ui/app/favicon.ico.mjs { IMAGE => \"[project]/twinklepod/twinklepod-monorepo/packages/ui/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/packages/ui/app/favicon.ico (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$packages$2f$ui$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 256,
    height: 256
};
}),
];

//# sourceMappingURL=twinklepod_twinklepod-monorepo_packages_ui_app_244463f3._.js.map