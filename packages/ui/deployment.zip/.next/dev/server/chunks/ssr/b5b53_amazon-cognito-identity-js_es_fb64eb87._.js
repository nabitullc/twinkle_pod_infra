module.exports = [
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/AuthenticationDetails.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ /** @class */ __turbopack_context__.s([
    "default",
    ()=>AuthenticationDetails
]);
var AuthenticationDetails = /*#__PURE__*/ function() {
    /**
   * Constructs a new AuthenticationDetails object
   * @param {object=} data Creation options.
   * @param {string} data.Username User being authenticated.
   * @param {string} data.Password Plain-text password to authenticate with.
   * @param {(AttributeArg[])?} data.ValidationData Application extra metadata.
   * @param {(AttributeArg[])?} data.AuthParamaters Authentication paramaters for custom auth.
   */ function AuthenticationDetails(data) {
        var _ref = data || {}, ValidationData = _ref.ValidationData, Username = _ref.Username, Password = _ref.Password, AuthParameters = _ref.AuthParameters, ClientMetadata = _ref.ClientMetadata;
        this.validationData = ValidationData || {};
        this.authParameters = AuthParameters || {};
        this.clientMetadata = ClientMetadata || {};
        this.username = Username;
        this.password = Password;
    }
    /**
   * @returns {string} the record's username
   */ var _proto = AuthenticationDetails.prototype;
    _proto.getUsername = function getUsername() {
        return this.username;
    };
    _proto.getPassword = function getPassword() {
        return this.password;
    };
    _proto.getValidationData = function getValidationData() {
        return this.validationData;
    };
    _proto.getAuthParameters = function getAuthParameters() {
        return this.authParameters;
    };
    _proto.getClientMetadata = function getClientMetadata() {
        return this.clientMetadata;
    };
    return AuthenticationDetails;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/utils/cryptoSecureRandomInt.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>cryptoSecureRandomInt
]);
var crypto;
// Native crypto from window (Browser)
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
// Native (experimental IE 11) crypto from window (Browser)
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
// Native crypto from global (NodeJS)
if (!crypto && ("TURBOPACK compile-time value", "object") !== 'undefined' && /*TURBOPACK member replacement*/ __turbopack_context__.g.crypto) {
    crypto = /*TURBOPACK member replacement*/ __turbopack_context__.g.crypto;
}
// Native crypto import via require (NodeJS)
if (!crypto && ("TURBOPACK compile-time value", "function") === 'function') {
    try {
        crypto = __turbopack_context__.r("[externals]/crypto [external] (crypto, cjs)");
    } catch (err) {}
}
function cryptoSecureRandomInt() {
    if (crypto) {
        // Use getRandomValues method (Browser)
        if (typeof crypto.getRandomValues === 'function') {
            try {
                return crypto.getRandomValues(new Uint32Array(1))[0];
            } catch (err) {}
        }
        // Use randomBytes method (NodeJS)
        if (typeof crypto.randomBytes === 'function') {
            try {
                return crypto.randomBytes(4).readInt32LE();
            } catch (err) {}
        }
    }
    throw new Error('Native crypto module could not be used to get secure random number.');
}
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/utils/WordArray.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WordArray
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$utils$2f$cryptoSecureRandomInt$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/utils/cryptoSecureRandomInt.js [app-ssr] (ecmascript)");
;
/**
 * Hex encoding strategy.
 * Converts a word array to a hex string.
 * @param {WordArray} wordArray The word array.
 * @return {string} The hex string.
 * @static
 */ function hexStringify(wordArray) {
    // Shortcuts
    var words = wordArray.words;
    var sigBytes = wordArray.sigBytes;
    // Convert
    var hexChars = [];
    for(var i = 0; i < sigBytes; i++){
        var bite = words[i >>> 2] >>> 24 - i % 4 * 8 & 0xff;
        hexChars.push((bite >>> 4).toString(16));
        hexChars.push((bite & 0x0f).toString(16));
    }
    return hexChars.join('');
}
var WordArray = /*#__PURE__*/ function() {
    function WordArray(words, sigBytes) {
        words = this.words = words || [];
        if (sigBytes != undefined) {
            this.sigBytes = sigBytes;
        } else {
            this.sigBytes = words.length * 4;
        }
    }
    var _proto = WordArray.prototype;
    _proto.random = function random(nBytes) {
        var words = [];
        for(var i = 0; i < nBytes; i += 4){
            words.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$utils$2f$cryptoSecureRandomInt$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])());
        }
        return new WordArray(words, nBytes);
    };
    _proto.toString = function toString() {
        return hexStringify(this);
    };
    return WordArray;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/BigInteger.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// A small implementation of BigInteger based on http://www-cs-students.stanford.edu/~tjw/jsbn/
//
// All public methods have been removed except the following:
//   new BigInteger(a, b) (only radix 2, 4, 8, 16 and 32 supported)
//   toString (only radix 2, 4, 8, 16 and 32 supported)
//   negate
//   abs
//   compareTo
//   bitLength
//   mod
//   equals
//   add
//   subtract
//   multiply
//   divide
//   modPow
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const __TURBOPACK__default__export__ = BigInteger;
/*
 * Copyright (c) 2003-2005  Tom Wu
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL TOM WU BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT ADVISED OF
 * THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY, ARISING OUT
 * OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * In addition, the following condition applies:
 *
 * All redistributions must retain an intact copy of this copyright notice
 * and disclaimer.
 */ // (public) Constructor
function BigInteger(a, b) {
    if (a != null) this.fromString(a, b);
}
// return new, unset BigInteger
function nbi() {
    return new BigInteger(null);
}
// Bits per digit
var dbits;
// JavaScript engine analysis
var canary = 0xdeadbeefcafe;
var j_lm = (canary & 0xffffff) == 0xefcafe;
// am: Compute w_j += (x*this_i), propagate carries,
// c is initial carry, returns final carry.
// c < 3*dvalue, x < 2*dvalue, this_i < dvalue
// We need to select the fastest one that works in this environment.
// am1: use a single mult and divide to get the high bits,
// max digit bits should be 26 because
// max internal value = 2*dvalue^2-2*dvalue (< 2^53)
function am1(i, x, w, j, c, n) {
    while(--n >= 0){
        var v = x * this[i++] + w[j] + c;
        c = Math.floor(v / 0x4000000);
        w[j++] = v & 0x3ffffff;
    }
    return c;
}
// am2 avoids a big mult-and-extract completely.
// Max digit bits should be <= 30 because we do bitwise ops
// on values up to 2*hdvalue^2-hdvalue-1 (< 2^31)
function am2(i, x, w, j, c, n) {
    var xl = x & 0x7fff, xh = x >> 15;
    while(--n >= 0){
        var l = this[i] & 0x7fff;
        var h = this[i++] >> 15;
        var m = xh * l + h * xl;
        l = xl * l + ((m & 0x7fff) << 15) + w[j] + (c & 0x3fffffff);
        c = (l >>> 30) + (m >>> 15) + xh * h + (c >>> 30);
        w[j++] = l & 0x3fffffff;
    }
    return c;
}
// Alternately, set max digit bits to 28 since some
// browsers slow down when dealing with 32-bit numbers.
function am3(i, x, w, j, c, n) {
    var xl = x & 0x3fff, xh = x >> 14;
    while(--n >= 0){
        var l = this[i] & 0x3fff;
        var h = this[i++] >> 14;
        var m = xh * l + h * xl;
        l = xl * l + ((m & 0x3fff) << 14) + w[j] + c;
        c = (l >> 28) + (m >> 14) + xh * h;
        w[j++] = l & 0xfffffff;
    }
    return c;
}
var inBrowser = typeof navigator !== 'undefined';
if (inBrowser && j_lm && navigator.appName == 'Microsoft Internet Explorer') {
    BigInteger.prototype.am = am2;
    dbits = 30;
} else if (inBrowser && j_lm && navigator.appName != 'Netscape') {
    BigInteger.prototype.am = am1;
    dbits = 26;
} else {
    // Mozilla/Netscape seems to prefer am3
    BigInteger.prototype.am = am3;
    dbits = 28;
}
BigInteger.prototype.DB = dbits;
BigInteger.prototype.DM = (1 << dbits) - 1;
BigInteger.prototype.DV = 1 << dbits;
var BI_FP = 52;
BigInteger.prototype.FV = Math.pow(2, BI_FP);
BigInteger.prototype.F1 = BI_FP - dbits;
BigInteger.prototype.F2 = 2 * dbits - BI_FP;
// Digit conversions
var BI_RM = '0123456789abcdefghijklmnopqrstuvwxyz';
var BI_RC = new Array();
var rr, vv;
rr = '0'.charCodeAt(0);
for(vv = 0; vv <= 9; ++vv)BI_RC[rr++] = vv;
rr = 'a'.charCodeAt(0);
for(vv = 10; vv < 36; ++vv)BI_RC[rr++] = vv;
rr = 'A'.charCodeAt(0);
for(vv = 10; vv < 36; ++vv)BI_RC[rr++] = vv;
function int2char(n) {
    return BI_RM.charAt(n);
}
function intAt(s, i) {
    var c = BI_RC[s.charCodeAt(i)];
    return c == null ? -1 : c;
}
// (protected) copy this to r
function bnpCopyTo(r) {
    for(var i = this.t - 1; i >= 0; --i)r[i] = this[i];
    r.t = this.t;
    r.s = this.s;
}
// (protected) set from integer value x, -DV <= x < DV
function bnpFromInt(x) {
    this.t = 1;
    this.s = x < 0 ? -1 : 0;
    if (x > 0) this[0] = x;
    else if (x < -1) this[0] = x + this.DV;
    else this.t = 0;
}
// return bigint initialized to value
function nbv(i) {
    var r = nbi();
    r.fromInt(i);
    return r;
}
// (protected) set from string and radix
function bnpFromString(s, b) {
    var k;
    if (b == 16) k = 4;
    else if (b == 8) k = 3;
    else if (b == 2) k = 1;
    else if (b == 32) k = 5;
    else if (b == 4) k = 2;
    else throw new Error('Only radix 2, 4, 8, 16, 32 are supported');
    this.t = 0;
    this.s = 0;
    var i = s.length, mi = false, sh = 0;
    while(--i >= 0){
        var x = intAt(s, i);
        if (x < 0) {
            if (s.charAt(i) == '-') mi = true;
            continue;
        }
        mi = false;
        if (sh == 0) this[this.t++] = x;
        else if (sh + k > this.DB) {
            this[this.t - 1] |= (x & (1 << this.DB - sh) - 1) << sh;
            this[this.t++] = x >> this.DB - sh;
        } else this[this.t - 1] |= x << sh;
        sh += k;
        if (sh >= this.DB) sh -= this.DB;
    }
    this.clamp();
    if (mi) BigInteger.ZERO.subTo(this, this);
}
// (protected) clamp off excess high words
function bnpClamp() {
    var c = this.s & this.DM;
    while(this.t > 0 && this[this.t - 1] == c)--this.t;
}
// (public) return string representation in given radix
function bnToString(b) {
    if (this.s < 0) return '-' + this.negate().toString(b);
    var k;
    if (b == 16) k = 4;
    else if (b == 8) k = 3;
    else if (b == 2) k = 1;
    else if (b == 32) k = 5;
    else if (b == 4) k = 2;
    else throw new Error('Only radix 2, 4, 8, 16, 32 are supported');
    var km = (1 << k) - 1, d, m = false, r = '', i = this.t;
    var p = this.DB - i * this.DB % k;
    if (i-- > 0) {
        if (p < this.DB && (d = this[i] >> p) > 0) {
            m = true;
            r = int2char(d);
        }
        while(i >= 0){
            if (p < k) {
                d = (this[i] & (1 << p) - 1) << k - p;
                d |= this[--i] >> (p += this.DB - k);
            } else {
                d = this[i] >> (p -= k) & km;
                if (p <= 0) {
                    p += this.DB;
                    --i;
                }
            }
            if (d > 0) m = true;
            if (m) r += int2char(d);
        }
    }
    return m ? r : '0';
}
// (public) -this
function bnNegate() {
    var r = nbi();
    BigInteger.ZERO.subTo(this, r);
    return r;
}
// (public) |this|
function bnAbs() {
    return this.s < 0 ? this.negate() : this;
}
// (public) return + if this > a, - if this < a, 0 if equal
function bnCompareTo(a) {
    var r = this.s - a.s;
    if (r != 0) return r;
    var i = this.t;
    r = i - a.t;
    if (r != 0) return this.s < 0 ? -r : r;
    while(--i >= 0)if ((r = this[i] - a[i]) != 0) return r;
    return 0;
}
// returns bit length of the integer x
function nbits(x) {
    var r = 1, t;
    if ((t = x >>> 16) != 0) {
        x = t;
        r += 16;
    }
    if ((t = x >> 8) != 0) {
        x = t;
        r += 8;
    }
    if ((t = x >> 4) != 0) {
        x = t;
        r += 4;
    }
    if ((t = x >> 2) != 0) {
        x = t;
        r += 2;
    }
    if ((t = x >> 1) != 0) {
        x = t;
        r += 1;
    }
    return r;
}
// (public) return the number of bits in "this"
function bnBitLength() {
    if (this.t <= 0) return 0;
    return this.DB * (this.t - 1) + nbits(this[this.t - 1] ^ this.s & this.DM);
}
// (protected) r = this << n*DB
function bnpDLShiftTo(n, r) {
    var i;
    for(i = this.t - 1; i >= 0; --i)r[i + n] = this[i];
    for(i = n - 1; i >= 0; --i)r[i] = 0;
    r.t = this.t + n;
    r.s = this.s;
}
// (protected) r = this >> n*DB
function bnpDRShiftTo(n, r) {
    for(var i = n; i < this.t; ++i)r[i - n] = this[i];
    r.t = Math.max(this.t - n, 0);
    r.s = this.s;
}
// (protected) r = this << n
function bnpLShiftTo(n, r) {
    var bs = n % this.DB;
    var cbs = this.DB - bs;
    var bm = (1 << cbs) - 1;
    var ds = Math.floor(n / this.DB), c = this.s << bs & this.DM, i;
    for(i = this.t - 1; i >= 0; --i){
        r[i + ds + 1] = this[i] >> cbs | c;
        c = (this[i] & bm) << bs;
    }
    for(i = ds - 1; i >= 0; --i)r[i] = 0;
    r[ds] = c;
    r.t = this.t + ds + 1;
    r.s = this.s;
    r.clamp();
}
// (protected) r = this >> n
function bnpRShiftTo(n, r) {
    r.s = this.s;
    var ds = Math.floor(n / this.DB);
    if (ds >= this.t) {
        r.t = 0;
        return;
    }
    var bs = n % this.DB;
    var cbs = this.DB - bs;
    var bm = (1 << bs) - 1;
    r[0] = this[ds] >> bs;
    for(var i = ds + 1; i < this.t; ++i){
        r[i - ds - 1] |= (this[i] & bm) << cbs;
        r[i - ds] = this[i] >> bs;
    }
    if (bs > 0) r[this.t - ds - 1] |= (this.s & bm) << cbs;
    r.t = this.t - ds;
    r.clamp();
}
// (protected) r = this - a
function bnpSubTo(a, r) {
    var i = 0, c = 0, m = Math.min(a.t, this.t);
    while(i < m){
        c += this[i] - a[i];
        r[i++] = c & this.DM;
        c >>= this.DB;
    }
    if (a.t < this.t) {
        c -= a.s;
        while(i < this.t){
            c += this[i];
            r[i++] = c & this.DM;
            c >>= this.DB;
        }
        c += this.s;
    } else {
        c += this.s;
        while(i < a.t){
            c -= a[i];
            r[i++] = c & this.DM;
            c >>= this.DB;
        }
        c -= a.s;
    }
    r.s = c < 0 ? -1 : 0;
    if (c < -1) r[i++] = this.DV + c;
    else if (c > 0) r[i++] = c;
    r.t = i;
    r.clamp();
}
// (protected) r = this * a, r != this,a (HAC 14.12)
// "this" should be the larger one if appropriate.
function bnpMultiplyTo(a, r) {
    var x = this.abs(), y = a.abs();
    var i = x.t;
    r.t = i + y.t;
    while(--i >= 0)r[i] = 0;
    for(i = 0; i < y.t; ++i)r[i + x.t] = x.am(0, y[i], r, i, 0, x.t);
    r.s = 0;
    r.clamp();
    if (this.s != a.s) BigInteger.ZERO.subTo(r, r);
}
// (protected) r = this^2, r != this (HAC 14.16)
function bnpSquareTo(r) {
    var x = this.abs();
    var i = r.t = 2 * x.t;
    while(--i >= 0)r[i] = 0;
    for(i = 0; i < x.t - 1; ++i){
        var c = x.am(i, x[i], r, 2 * i, 0, 1);
        if ((r[i + x.t] += x.am(i + 1, 2 * x[i], r, 2 * i + 1, c, x.t - i - 1)) >= x.DV) {
            r[i + x.t] -= x.DV;
            r[i + x.t + 1] = 1;
        }
    }
    if (r.t > 0) r[r.t - 1] += x.am(i, x[i], r, 2 * i, 0, 1);
    r.s = 0;
    r.clamp();
}
// (protected) divide this by m, quotient and remainder to q, r (HAC 14.20)
// r != q, this != m.  q or r may be null.
function bnpDivRemTo(m, q, r) {
    var pm = m.abs();
    if (pm.t <= 0) return;
    var pt = this.abs();
    if (pt.t < pm.t) {
        if (q != null) q.fromInt(0);
        if (r != null) this.copyTo(r);
        return;
    }
    if (r == null) r = nbi();
    var y = nbi(), ts = this.s, ms = m.s;
    var nsh = this.DB - nbits(pm[pm.t - 1]);
    // normalize modulus
    if (nsh > 0) {
        pm.lShiftTo(nsh, y);
        pt.lShiftTo(nsh, r);
    } else {
        pm.copyTo(y);
        pt.copyTo(r);
    }
    var ys = y.t;
    var y0 = y[ys - 1];
    if (y0 == 0) return;
    var yt = y0 * (1 << this.F1) + (ys > 1 ? y[ys - 2] >> this.F2 : 0);
    var d1 = this.FV / yt, d2 = (1 << this.F1) / yt, e = 1 << this.F2;
    var i = r.t, j = i - ys, t = q == null ? nbi() : q;
    y.dlShiftTo(j, t);
    if (r.compareTo(t) >= 0) {
        r[r.t++] = 1;
        r.subTo(t, r);
    }
    BigInteger.ONE.dlShiftTo(ys, t);
    t.subTo(y, y);
    // "negative" y so we can replace sub with am later
    while(y.t < ys)y[y.t++] = 0;
    while(--j >= 0){
        // Estimate quotient digit
        var qd = r[--i] == y0 ? this.DM : Math.floor(r[i] * d1 + (r[i - 1] + e) * d2);
        if ((r[i] += y.am(0, qd, r, j, 0, ys)) < qd) {
            // Try it out
            y.dlShiftTo(j, t);
            r.subTo(t, r);
            while(r[i] < --qd)r.subTo(t, r);
        }
    }
    if (q != null) {
        r.drShiftTo(ys, q);
        if (ts != ms) BigInteger.ZERO.subTo(q, q);
    }
    r.t = ys;
    r.clamp();
    if (nsh > 0) r.rShiftTo(nsh, r);
    // Denormalize remainder
    if (ts < 0) BigInteger.ZERO.subTo(r, r);
}
// (public) this mod a
function bnMod(a) {
    var r = nbi();
    this.abs().divRemTo(a, null, r);
    if (this.s < 0 && r.compareTo(BigInteger.ZERO) > 0) a.subTo(r, r);
    return r;
}
// (protected) return "-1/this % 2^DB"; useful for Mont. reduction
// justification:
//         xy == 1 (mod m)
//         xy =  1+km
//   xy(2-xy) = (1+km)(1-km)
// x[y(2-xy)] = 1-k^2m^2
// x[y(2-xy)] == 1 (mod m^2)
// if y is 1/x mod m, then y(2-xy) is 1/x mod m^2
// should reduce x and y(2-xy) by m^2 at each step to keep size bounded.
// JS multiply "overflows" differently from C/C++, so care is needed here.
function bnpInvDigit() {
    if (this.t < 1) return 0;
    var x = this[0];
    if ((x & 1) == 0) return 0;
    var y = x & 3;
    // y == 1/x mod 2^2
    y = y * (2 - (x & 0xf) * y) & 0xf;
    // y == 1/x mod 2^4
    y = y * (2 - (x & 0xff) * y) & 0xff;
    // y == 1/x mod 2^8
    y = y * (2 - ((x & 0xffff) * y & 0xffff)) & 0xffff;
    // y == 1/x mod 2^16
    // last step - calculate inverse mod DV directly;
    // assumes 16 < DB <= 32 and assumes ability to handle 48-bit ints
    y = y * (2 - x * y % this.DV) % this.DV;
    // y == 1/x mod 2^dbits
    // we really want the negative inverse, and -DV < y < DV
    return y > 0 ? this.DV - y : -y;
}
function bnEquals(a) {
    return this.compareTo(a) == 0;
}
// (protected) r = this + a
function bnpAddTo(a, r) {
    var i = 0, c = 0, m = Math.min(a.t, this.t);
    while(i < m){
        c += this[i] + a[i];
        r[i++] = c & this.DM;
        c >>= this.DB;
    }
    if (a.t < this.t) {
        c += a.s;
        while(i < this.t){
            c += this[i];
            r[i++] = c & this.DM;
            c >>= this.DB;
        }
        c += this.s;
    } else {
        c += this.s;
        while(i < a.t){
            c += a[i];
            r[i++] = c & this.DM;
            c >>= this.DB;
        }
        c += a.s;
    }
    r.s = c < 0 ? -1 : 0;
    if (c > 0) r[i++] = c;
    else if (c < -1) r[i++] = this.DV + c;
    r.t = i;
    r.clamp();
}
// (public) this + a
function bnAdd(a) {
    var r = nbi();
    this.addTo(a, r);
    return r;
}
// (public) this - a
function bnSubtract(a) {
    var r = nbi();
    this.subTo(a, r);
    return r;
}
// (public) this * a
function bnMultiply(a) {
    var r = nbi();
    this.multiplyTo(a, r);
    return r;
}
// (public) this / a
function bnDivide(a) {
    var r = nbi();
    this.divRemTo(a, r, null);
    return r;
}
// Montgomery reduction
function Montgomery(m) {
    this.m = m;
    this.mp = m.invDigit();
    this.mpl = this.mp & 0x7fff;
    this.mph = this.mp >> 15;
    this.um = (1 << m.DB - 15) - 1;
    this.mt2 = 2 * m.t;
}
// xR mod m
function montConvert(x) {
    var r = nbi();
    x.abs().dlShiftTo(this.m.t, r);
    r.divRemTo(this.m, null, r);
    if (x.s < 0 && r.compareTo(BigInteger.ZERO) > 0) this.m.subTo(r, r);
    return r;
}
// x/R mod m
function montRevert(x) {
    var r = nbi();
    x.copyTo(r);
    this.reduce(r);
    return r;
}
// x = x/R mod m (HAC 14.32)
function montReduce(x) {
    while(x.t <= this.mt2)// pad x so am has enough room later
    x[x.t++] = 0;
    for(var i = 0; i < this.m.t; ++i){
        // faster way of calculating u0 = x[i]*mp mod DV
        var j = x[i] & 0x7fff;
        var u0 = j * this.mpl + ((j * this.mph + (x[i] >> 15) * this.mpl & this.um) << 15) & x.DM;
        // use am to combine the multiply-shift-add into one call
        j = i + this.m.t;
        x[j] += this.m.am(0, u0, x, i, 0, this.m.t);
        // propagate carry
        while(x[j] >= x.DV){
            x[j] -= x.DV;
            x[++j]++;
        }
    }
    x.clamp();
    x.drShiftTo(this.m.t, x);
    if (x.compareTo(this.m) >= 0) x.subTo(this.m, x);
}
// r = "x^2/R mod m"; x != r
function montSqrTo(x, r) {
    x.squareTo(r);
    this.reduce(r);
}
// r = "xy/R mod m"; x,y != r
function montMulTo(x, y, r) {
    x.multiplyTo(y, r);
    this.reduce(r);
}
Montgomery.prototype.convert = montConvert;
Montgomery.prototype.revert = montRevert;
Montgomery.prototype.reduce = montReduce;
Montgomery.prototype.mulTo = montMulTo;
Montgomery.prototype.sqrTo = montSqrTo;
// (public) this^e % m (HAC 14.85)
function bnModPow(e, m, callback) {
    var i = e.bitLength(), k, r = nbv(1), z = new Montgomery(m);
    if (i <= 0) return r;
    else if (i < 18) k = 1;
    else if (i < 48) k = 3;
    else if (i < 144) k = 4;
    else if (i < 768) k = 5;
    else k = 6;
    // precomputation
    var g = new Array(), n = 3, k1 = k - 1, km = (1 << k) - 1;
    g[1] = z.convert(this);
    if (k > 1) {
        var g2 = nbi();
        z.sqrTo(g[1], g2);
        while(n <= km){
            g[n] = nbi();
            z.mulTo(g2, g[n - 2], g[n]);
            n += 2;
        }
    }
    var j = e.t - 1, w, is1 = true, r2 = nbi(), t;
    i = nbits(e[j]) - 1;
    while(j >= 0){
        if (i >= k1) w = e[j] >> i - k1 & km;
        else {
            w = (e[j] & (1 << i + 1) - 1) << k1 - i;
            if (j > 0) w |= e[j - 1] >> this.DB + i - k1;
        }
        n = k;
        while((w & 1) == 0){
            w >>= 1;
            --n;
        }
        if ((i -= n) < 0) {
            i += this.DB;
            --j;
        }
        if (is1) {
            // ret == 1, don't bother squaring or multiplying it
            g[w].copyTo(r);
            is1 = false;
        } else {
            while(n > 1){
                z.sqrTo(r, r2);
                z.sqrTo(r2, r);
                n -= 2;
            }
            if (n > 0) z.sqrTo(r, r2);
            else {
                t = r;
                r = r2;
                r2 = t;
            }
            z.mulTo(r2, g[w], r);
        }
        while(j >= 0 && (e[j] & 1 << i) == 0){
            z.sqrTo(r, r2);
            t = r;
            r = r2;
            r2 = t;
            if (--i < 0) {
                i = this.DB - 1;
                --j;
            }
        }
    }
    var result = z.revert(r);
    callback(null, result);
    return result;
}
// protected
BigInteger.prototype.copyTo = bnpCopyTo;
BigInteger.prototype.fromInt = bnpFromInt;
BigInteger.prototype.fromString = bnpFromString;
BigInteger.prototype.clamp = bnpClamp;
BigInteger.prototype.dlShiftTo = bnpDLShiftTo;
BigInteger.prototype.drShiftTo = bnpDRShiftTo;
BigInteger.prototype.lShiftTo = bnpLShiftTo;
BigInteger.prototype.rShiftTo = bnpRShiftTo;
BigInteger.prototype.subTo = bnpSubTo;
BigInteger.prototype.multiplyTo = bnpMultiplyTo;
BigInteger.prototype.squareTo = bnpSquareTo;
BigInteger.prototype.divRemTo = bnpDivRemTo;
BigInteger.prototype.invDigit = bnpInvDigit;
BigInteger.prototype.addTo = bnpAddTo;
// public
BigInteger.prototype.toString = bnToString;
BigInteger.prototype.negate = bnNegate;
BigInteger.prototype.abs = bnAbs;
BigInteger.prototype.compareTo = bnCompareTo;
BigInteger.prototype.bitLength = bnBitLength;
BigInteger.prototype.mod = bnMod;
BigInteger.prototype.equals = bnEquals;
BigInteger.prototype.add = bnAdd;
BigInteger.prototype.subtract = bnSubtract;
BigInteger.prototype.multiply = bnMultiply;
BigInteger.prototype.divide = bnDivide;
BigInteger.prototype.modPow = bnModPow;
// "constants"
BigInteger.ZERO = nbv(0);
BigInteger.ONE = nbv(1);
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/AuthenticationHelper.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ __turbopack_context__.s([
    "default",
    ()=>AuthenticationHelper
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/buffer [external] (buffer, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$utils$2f$WordArray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/utils/WordArray.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$node_modules$2f40$aws$2d$crypto$2f$sha256$2d$js$2f$build$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/node_modules/@aws-crypto/sha256-js/build/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/BigInteger.js [app-ssr] (ecmascript)");
;
;
;
/**
 * Returns a Buffer with a sequence of random nBytes
 *
 * @param {number} nBytes
 * @returns {Buffer} fixed-length sequence of random bytes
 */ function randomBytes(nBytes) {
    return __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$utils$2f$WordArray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]().random(nBytes).toString(), 'hex');
}
;
/**
 * Tests if a hex string has it most significant bit set (case-insensitive regex)
 */ var HEX_MSB_REGEX = /^[89a-f]/i;
var initN = 'FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1' + '29024E088A67CC74020BBEA63B139B22514A08798E3404DD' + 'EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245' + 'E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED' + 'EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D' + 'C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F' + '83655D23DCA3AD961C62F356208552BB9ED529077096966D' + '670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B' + 'E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9' + 'DE2BCBF6955817183995497CEA956AE515D2261898FA0510' + '15728E5A8AAAC42DAD33170D04507A33A85521ABDF1CBA64' + 'ECFB850458DBEF0A8AEA71575D060C7DB3970F85A6E1E4C7' + 'ABF5AE8CDB0933D71E8C94E04A25619DCEE3D2261AD2EE6B' + 'F12FFA06D98A0864D87602733EC86A64521F2B18177B200C' + 'BBE117577A615D6C770988C0BAD946E208E24FA074E5AB31' + '43DB5BFCE0FD108E4B82D120A93AD2CAFFFFFFFFFFFFFFFF';
var newPasswordRequiredChallengeUserAttributePrefix = 'userAttributes.';
/** @class */ var AuthenticationHelper = /*#__PURE__*/ function() {
    /**
   * Constructs a new AuthenticationHelper object
   * @param {string} PoolName Cognito user pool name.
   */ function AuthenticationHelper(PoolName) {
        this.N = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](initN, 16);
        this.g = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]('2', 16);
        this.k = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.hexHash("" + this.padHex(this.N) + this.padHex(this.g)), 16);
        this.smallAValue = this.generateRandomSmallA();
        this.getLargeAValue(function() {});
        this.infoBits = __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from('Caldera Derived Key', 'utf8');
        this.poolName = PoolName;
    }
    /**
   * @returns {BigInteger} small A, a random number
   */ var _proto = AuthenticationHelper.prototype;
    _proto.getSmallAValue = function getSmallAValue() {
        return this.smallAValue;
    };
    _proto.getLargeAValue = function getLargeAValue(callback) {
        var _this = this;
        if (this.largeAValue) {
            callback(null, this.largeAValue);
        } else {
            this.calculateA(this.smallAValue, function(err, largeAValue) {
                if (err) {
                    callback(err, null);
                }
                _this.largeAValue = largeAValue;
                callback(null, _this.largeAValue);
            });
        }
    };
    _proto.generateRandomSmallA = function generateRandomSmallA() {
        // This will be interpreted as a postive 128-bit integer
        var hexRandom = randomBytes(128).toString('hex');
        var randomBigInt = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](hexRandom, 16);
        // There is no need to do randomBigInt.mod(this.N - 1) as N (3072-bit) is > 128 bytes (1024-bit)
        return randomBigInt;
    };
    _proto.generateRandomString = function generateRandomString() {
        return randomBytes(40).toString('base64');
    };
    _proto.getRandomPassword = function getRandomPassword() {
        return this.randomPassword;
    };
    _proto.getSaltDevices = function getSaltDevices() {
        return this.SaltToHashDevices;
    };
    _proto.getVerifierDevices = function getVerifierDevices() {
        return this.verifierDevices;
    };
    _proto.generateHashDevice = function generateHashDevice(deviceGroupKey, username, callback) {
        var _this2 = this;
        this.randomPassword = this.generateRandomString();
        var combinedString = "" + deviceGroupKey + username + ":" + this.randomPassword;
        var hashedString = this.hash(combinedString);
        var hexRandom = randomBytes(16).toString('hex');
        // The random hex will be unambiguously represented as a postive integer
        this.SaltToHashDevices = this.padHex(new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](hexRandom, 16));
        this.g.modPow(new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.hexHash(this.SaltToHashDevices + hashedString), 16), this.N, function(err, verifierDevicesNotPadded) {
            if (err) {
                callback(err, null);
            }
            _this2.verifierDevices = _this2.padHex(verifierDevicesNotPadded);
            callback(null, null);
        });
    };
    _proto.calculateA = function calculateA(a, callback) {
        var _this3 = this;
        this.g.modPow(a, this.N, function(err, A) {
            if (err) {
                callback(err, null);
            }
            if (A.mod(_this3.N).equals(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].ZERO)) {
                callback(new Error('Illegal paramater. A mod N cannot be 0.'), null);
            }
            callback(null, A);
        });
    };
    _proto.calculateU = function calculateU(A, B) {
        this.UHexHash = this.hexHash(this.padHex(A) + this.padHex(B));
        var finalU = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.UHexHash, 16);
        return finalU;
    };
    _proto.hash = function hash(buf) {
        var awsCryptoHash = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$node_modules$2f40$aws$2d$crypto$2f$sha256$2d$js$2f$build$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Sha256"]();
        awsCryptoHash.update(buf);
        var resultFromAWSCrypto = awsCryptoHash.digestSync();
        var hashHex = __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(resultFromAWSCrypto).toString('hex');
        return new Array(64 - hashHex.length).join('0') + hashHex;
    };
    _proto.hexHash = function hexHash(hexStr) {
        return this.hash(__TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(hexStr, 'hex'));
    };
    _proto.computehkdf = function computehkdf(ikm, salt) {
        var infoBitsBuffer = __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].concat([
            this.infoBits,
            __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(String.fromCharCode(1), 'utf8')
        ]);
        var awsCryptoHash = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$node_modules$2f40$aws$2d$crypto$2f$sha256$2d$js$2f$build$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Sha256"](salt);
        awsCryptoHash.update(ikm);
        var resultFromAWSCryptoPrk = awsCryptoHash.digestSync();
        var awsCryptoHashHmac = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$node_modules$2f40$aws$2d$crypto$2f$sha256$2d$js$2f$build$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Sha256"](resultFromAWSCryptoPrk);
        awsCryptoHashHmac.update(infoBitsBuffer);
        var resultFromAWSCryptoHmac = awsCryptoHashHmac.digestSync();
        var hashHexFromAWSCrypto = resultFromAWSCryptoHmac;
        var currentHex = hashHexFromAWSCrypto.slice(0, 16);
        return currentHex;
    };
    _proto.getPasswordAuthenticationKey = function getPasswordAuthenticationKey(username, password, serverBValue, salt, callback) {
        var _this4 = this;
        if (serverBValue.mod(this.N).equals(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].ZERO)) {
            throw new Error('B cannot be zero.');
        }
        this.UValue = this.calculateU(this.largeAValue, serverBValue);
        if (this.UValue.equals(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].ZERO)) {
            throw new Error('U cannot be zero.');
        }
        var usernamePassword = "" + this.poolName + username + ":" + password;
        var usernamePasswordHash = this.hash(usernamePassword);
        var xValue = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.hexHash(this.padHex(salt) + usernamePasswordHash), 16);
        this.calculateS(xValue, serverBValue, function(err, sValue) {
            if (err) {
                callback(err, null);
            }
            var hkdf = _this4.computehkdf(__TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(_this4.padHex(sValue), 'hex'), __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(_this4.padHex(_this4.UValue), 'hex'));
            callback(null, hkdf);
        });
    };
    _proto.calculateS = function calculateS(xValue, serverBValue, callback) {
        var _this5 = this;
        this.g.modPow(xValue, this.N, function(err, gModPowXN) {
            if (err) {
                callback(err, null);
            }
            var intValue2 = serverBValue.subtract(_this5.k.multiply(gModPowXN));
            intValue2.modPow(_this5.smallAValue.add(_this5.UValue.multiply(xValue)), _this5.N, function(err2, result) {
                if (err2) {
                    callback(err2, null);
                }
                callback(null, result.mod(_this5.N));
            });
        });
    };
    _proto.getNewPasswordRequiredChallengeUserAttributePrefix = function getNewPasswordRequiredChallengeUserAttributePrefix() {
        return newPasswordRequiredChallengeUserAttributePrefix;
    };
    _proto.padHex = function padHex(bigInt) {
        if (!(bigInt instanceof __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            throw new Error('Not a BigInteger');
        }
        var isNegative = bigInt.compareTo(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].ZERO) < 0;
        /* Get a hex string for abs(bigInt) */ var hexStr = bigInt.abs().toString(16);
        /* Pad hex to even length if needed */ hexStr = hexStr.length % 2 !== 0 ? "0" + hexStr : hexStr;
        /* Prepend "00" if the most significant bit is set */ hexStr = HEX_MSB_REGEX.test(hexStr) ? "00" + hexStr : hexStr;
        if (isNegative) {
            /* Flip the bits of the representation */ var invertedNibbles = hexStr.split('').map(function(x) {
                var invertedNibble = ~parseInt(x, 16) & 0xf;
                return '0123456789ABCDEF'.charAt(invertedNibble);
            }).join('');
            /* After flipping the bits, add one to get the 2's complement representation */ var flippedBitsBI = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](invertedNibbles, 16).add(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].ONE);
            hexStr = flippedBitsBI.toString(16);
            /*
      For hex strings starting with 'FF8', 'FF' can be dropped, e.g. 0xFFFF80=0xFF80=0x80=-128
      		Any sequence of '1' bits on the left can always be substituted with a single '1' bit
      without changing the represented value.
      		This only happens in the case when the input is 80...00
      */ if (hexStr.toUpperCase().startsWith('FF8')) {
                hexStr = hexStr.substring(2);
            }
        }
        return hexStr;
    };
    return AuthenticationHelper;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoJwtToken.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ __turbopack_context__.s([
    "default",
    ()=>CognitoJwtToken
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/buffer [external] (buffer, cjs)");
;
/** @class */ var CognitoJwtToken = /*#__PURE__*/ function() {
    /**
   * Constructs a new CognitoJwtToken object
   * @param {string=} token The JWT token.
   */ function CognitoJwtToken(token) {
        // Assign object
        this.jwtToken = token || '';
        this.payload = this.decodePayload();
    }
    /**
   * @returns {string} the record's token.
   */ var _proto = CognitoJwtToken.prototype;
    _proto.getJwtToken = function getJwtToken() {
        return this.jwtToken;
    };
    _proto.getExpiration = function getExpiration() {
        return this.payload.exp;
    };
    _proto.getIssuedAt = function getIssuedAt() {
        return this.payload.iat;
    };
    _proto.decodePayload = function decodePayload() {
        var payload = this.jwtToken.split('.')[1];
        try {
            return JSON.parse(__TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(payload, 'base64').toString('utf8'));
        } catch (err) {
            return {};
        }
    };
    return CognitoJwtToken;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoAccessToken.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CognitoAccessToken
]);
/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoJwtToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoJwtToken.js [app-ssr] (ecmascript)");
function _inheritsLoose(t, o) {
    t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o);
}
function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
        return t.__proto__ = e, t;
    }, _setPrototypeOf(t, e);
}
;
/** @class */ var CognitoAccessToken = /*#__PURE__*/ function(_CognitoJwtToken) {
    /**
   * Constructs a new CognitoAccessToken object
   * @param {string=} AccessToken The JWT access token.
   */ function CognitoAccessToken(_temp) {
        var _ref = _temp === void 0 ? {} : _temp, AccessToken = _ref.AccessToken;
        return _CognitoJwtToken.call(this, AccessToken || '') || this;
    }
    _inheritsLoose(CognitoAccessToken, _CognitoJwtToken);
    return CognitoAccessToken;
}(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoJwtToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoIdToken.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CognitoIdToken
]);
/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoJwtToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoJwtToken.js [app-ssr] (ecmascript)");
function _inheritsLoose(t, o) {
    t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o);
}
function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
        return t.__proto__ = e, t;
    }, _setPrototypeOf(t, e);
}
;
/** @class */ var CognitoIdToken = /*#__PURE__*/ function(_CognitoJwtToken) {
    /**
   * Constructs a new CognitoIdToken object
   * @param {string=} IdToken The JWT Id token
   */ function CognitoIdToken(_temp) {
        var _ref = _temp === void 0 ? {} : _temp, IdToken = _ref.IdToken;
        return _CognitoJwtToken.call(this, IdToken || '') || this;
    }
    _inheritsLoose(CognitoIdToken, _CognitoJwtToken);
    return CognitoIdToken;
}(__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoJwtToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoRefreshToken.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ /** @class */ __turbopack_context__.s([
    "default",
    ()=>CognitoRefreshToken
]);
var CognitoRefreshToken = /*#__PURE__*/ function() {
    /**
   * Constructs a new CognitoRefreshToken object
   * @param {string=} RefreshToken The JWT refresh token.
   */ function CognitoRefreshToken(_temp) {
        var _ref = _temp === void 0 ? {} : _temp, RefreshToken = _ref.RefreshToken;
        // Assign object
        this.token = RefreshToken || '';
    }
    /**
   * @returns {string} the record's token.
   */ var _proto = CognitoRefreshToken.prototype;
    _proto.getToken = function getToken() {
        return this.token;
    };
    return CognitoRefreshToken;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/Platform/version.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// generated by genversion
__turbopack_context__.s([
    "version",
    ()=>version
]);
var version = '5.0.4';
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/Platform/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ __turbopack_context__.s([
    "Platform",
    ()=>Platform,
    "default",
    ()=>__TURBOPACK__default__export__,
    "getUserAgent",
    ()=>getUserAgent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$Platform$2f$version$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/Platform/version.js [app-ssr] (ecmascript)");
;
var BASE_USER_AGENT = "aws-amplify/" + __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$Platform$2f$version$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["version"];
var Platform = {
    userAgent: BASE_USER_AGENT,
    isReactNative: typeof navigator !== 'undefined' && navigator.product === 'ReactNative'
};
var getUserAgent = function getUserAgent() {
    return Platform.userAgent;
};
const __TURBOPACK__default__export__ = Platform;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserSession.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ /** @class */ __turbopack_context__.s([
    "default",
    ()=>CognitoUserSession
]);
var CognitoUserSession = /*#__PURE__*/ function() {
    /**
   * Constructs a new CognitoUserSession object
   * @param {CognitoIdToken} IdToken The session's Id token.
   * @param {CognitoRefreshToken=} RefreshToken The session's refresh token.
   * @param {CognitoAccessToken} AccessToken The session's access token.
   * @param {int} ClockDrift The saved computer's clock drift or undefined to force calculation.
   */ function CognitoUserSession(_temp) {
        var _ref = _temp === void 0 ? {} : _temp, IdToken = _ref.IdToken, RefreshToken = _ref.RefreshToken, AccessToken = _ref.AccessToken, ClockDrift = _ref.ClockDrift;
        if (AccessToken == null || IdToken == null) {
            throw new Error('Id token and Access Token must be present.');
        }
        this.idToken = IdToken;
        this.refreshToken = RefreshToken;
        this.accessToken = AccessToken;
        this.clockDrift = ClockDrift === undefined ? this.calculateClockDrift() : ClockDrift;
    }
    /**
   * @returns {CognitoIdToken} the session's Id token
   */ var _proto = CognitoUserSession.prototype;
    _proto.getIdToken = function getIdToken() {
        return this.idToken;
    };
    _proto.getRefreshToken = function getRefreshToken() {
        return this.refreshToken;
    };
    _proto.getAccessToken = function getAccessToken() {
        return this.accessToken;
    };
    _proto.getClockDrift = function getClockDrift() {
        return this.clockDrift;
    };
    _proto.calculateClockDrift = function calculateClockDrift() {
        var now = Math.floor(new Date() / 1000);
        var iat = Math.min(this.accessToken.getIssuedAt(), this.idToken.getIssuedAt());
        return now - iat;
    };
    _proto.isValid = function isValid() {
        var now = Math.floor(new Date() / 1000);
        var adjusted = now - this.clockDrift;
        return adjusted < this.accessToken.getExpiration() && adjusted < this.idToken.getExpiration();
    };
    return CognitoUserSession;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/DateHelper.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ __turbopack_context__.s([
    "default",
    ()=>DateHelper
]);
var monthNames = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
];
var weekNames = [
    'Sun',
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat'
];
/** @class */ var DateHelper = /*#__PURE__*/ function() {
    function DateHelper() {}
    var _proto = DateHelper.prototype;
    /**
   * @returns {string} The current time in "ddd MMM D HH:mm:ss UTC YYYY" format.
   */ _proto.getNowString = function getNowString() {
        var now = new Date();
        var weekDay = weekNames[now.getUTCDay()];
        var month = monthNames[now.getUTCMonth()];
        var day = now.getUTCDate();
        var hours = now.getUTCHours();
        if (hours < 10) {
            hours = "0" + hours;
        }
        var minutes = now.getUTCMinutes();
        if (minutes < 10) {
            minutes = "0" + minutes;
        }
        var seconds = now.getUTCSeconds();
        if (seconds < 10) {
            seconds = "0" + seconds;
        }
        var year = now.getUTCFullYear();
        // ddd MMM D HH:mm:ss UTC YYYY
        var dateNow = weekDay + " " + month + " " + day + " " + hours + ":" + minutes + ":" + seconds + " UTC " + year;
        return dateNow;
    };
    return DateHelper;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserAttribute.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ /** @class */ __turbopack_context__.s([
    "default",
    ()=>CognitoUserAttribute
]);
var CognitoUserAttribute = /*#__PURE__*/ function() {
    /**
   * Constructs a new CognitoUserAttribute object
   * @param {string=} Name The record's name
   * @param {string=} Value The record's value
   */ function CognitoUserAttribute(_temp) {
        var _ref = _temp === void 0 ? {} : _temp, Name = _ref.Name, Value = _ref.Value;
        this.Name = Name || '';
        this.Value = Value || '';
    }
    /**
   * @returns {string} the record's value.
   */ var _proto = CognitoUserAttribute.prototype;
    _proto.getValue = function getValue() {
        return this.Value;
    };
    _proto.setValue = function setValue(value) {
        this.Value = value;
        return this;
    };
    _proto.getName = function getName() {
        return this.Name;
    };
    _proto.setName = function setName(name) {
        this.Name = name;
        return this;
    };
    _proto.toString = function toString() {
        return JSON.stringify(this);
    };
    _proto.toJSON = function toJSON() {
        return {
            Name: this.Name,
            Value: this.Value
        };
    };
    return CognitoUserAttribute;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/StorageHelper.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ __turbopack_context__.s([
    "MemoryStorage",
    ()=>MemoryStorage,
    "default",
    ()=>StorageHelper
]);
var dataMemory = {};
var MemoryStorage = /*#__PURE__*/ function() {
    function MemoryStorage() {}
    /**
   * This is used to set a specific item in storage
   * @param {string} key - the key for the item
   * @param {object} value - the value
   * @returns {string} value that was set
   */ MemoryStorage.setItem = function setItem(key, value) {
        dataMemory[key] = value;
        return dataMemory[key];
    };
    MemoryStorage.getItem = function getItem(key) {
        return Object.prototype.hasOwnProperty.call(dataMemory, key) ? dataMemory[key] : undefined;
    };
    MemoryStorage.removeItem = function removeItem(key) {
        return delete dataMemory[key];
    };
    MemoryStorage.clear = function clear() {
        dataMemory = {};
        return dataMemory;
    };
    return MemoryStorage;
}();
/** @class */ var StorageHelper = /*#__PURE__*/ function() {
    /**
   * This is used to get a storage object
   * @returns {object} the storage
   */ function StorageHelper() {
        try {
            this.storageWindow = window.localStorage;
            this.storageWindow.setItem('aws.cognito.test-ls', 1);
            this.storageWindow.removeItem('aws.cognito.test-ls');
        } catch (exception) {
            this.storageWindow = MemoryStorage;
        }
    }
    /**
   * This is used to return the storage
   * @returns {object} the storage
   */ var _proto = StorageHelper.prototype;
    _proto.getStorage = function getStorage() {
        return this.storageWindow;
    };
    return StorageHelper;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUser.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ __turbopack_context__.s([
    "default",
    ()=>CognitoUser
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/buffer [external] (buffer, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$node_modules$2f40$aws$2d$crypto$2f$sha256$2d$js$2f$build$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/node_modules/@aws-crypto/sha256-js/build/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$Platform$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/Platform/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/BigInteger.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/AuthenticationHelper.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoAccessToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoAccessToken.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoIdToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoIdToken.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoRefreshToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoRefreshToken.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserSession$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserSession.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$DateHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/DateHelper.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserAttribute$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserAttribute.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$StorageHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/StorageHelper.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
/**
 * @callback nodeCallback
 * @template T result
 * @param {*} err The operation failure reason, or null.
 * @param {T} result The operation result.
 */ /**
 * @callback onFailure
 * @param {*} err Failure reason.
 */ /**
 * @callback onSuccess
 * @template T result
 * @param {T} result The operation result.
 */ /**
 * @callback mfaRequired
 * @param {*} details MFA challenge details.
 */ /**
 * @callback customChallenge
 * @param {*} details Custom challenge details.
 */ /**
 * @callback inputVerificationCode
 * @param {*} data Server response.
 */ /**
 * @callback authSuccess
 * @param {CognitoUserSession} session The new session.
 * @param {bool=} userConfirmationNecessary User must be confirmed.
 */ var isNavigatorAvailable = typeof navigator !== 'undefined';
var userAgent = isNavigatorAvailable ? __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$Platform$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Platform"].isReactNative ? 'react-native' : navigator.userAgent : 'nodejs';
/** @class */ var CognitoUser = /*#__PURE__*/ function() {
    /**
   * Constructs a new CognitoUser object
   * @param {object} data Creation options
   * @param {string} data.Username The user's username.
   * @param {CognitoUserPool} data.Pool Pool containing the user.
   * @param {object} data.Storage Optional storage object.
   */ function CognitoUser(data) {
        if (data == null || data.Username == null || data.Pool == null) {
            throw new Error('Username and Pool information are required.');
        }
        this.username = data.Username || '';
        this.pool = data.Pool;
        this.Session = null;
        this.client = data.Pool.client;
        this.signInUserSession = null;
        this.authenticationFlowType = 'USER_SRP_AUTH';
        this.storage = data.Storage || new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$StorageHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]().getStorage();
        this.keyPrefix = "CognitoIdentityServiceProvider." + this.pool.getClientId();
        this.userDataKey = this.keyPrefix + "." + this.username + ".userData";
    }
    /**
   * Sets the session for this user
   * @param {CognitoUserSession} signInUserSession the session
   * @returns {void}
   */ var _proto = CognitoUser.prototype;
    _proto.setSignInUserSession = function setSignInUserSession(signInUserSession) {
        this.clearCachedUserData();
        this.signInUserSession = signInUserSession;
        this.cacheTokens();
    };
    _proto.getSignInUserSession = function getSignInUserSession() {
        return this.signInUserSession;
    };
    _proto.getUsername = function getUsername() {
        return this.username;
    };
    _proto.getAuthenticationFlowType = function getAuthenticationFlowType() {
        return this.authenticationFlowType;
    };
    _proto.setAuthenticationFlowType = function setAuthenticationFlowType(authenticationFlowType) {
        this.authenticationFlowType = authenticationFlowType;
    };
    _proto.initiateAuth = function initiateAuth(authDetails, callback) {
        var _this = this;
        var authParameters = authDetails.getAuthParameters();
        authParameters.USERNAME = this.username;
        var clientMetaData = Object.keys(authDetails.getValidationData()).length !== 0 ? authDetails.getValidationData() : authDetails.getClientMetadata();
        var jsonReq = {
            AuthFlow: 'CUSTOM_AUTH',
            ClientId: this.pool.getClientId(),
            AuthParameters: authParameters,
            ClientMetadata: clientMetaData
        };
        if (this.getUserContextData()) {
            jsonReq.UserContextData = this.getUserContextData();
        }
        this.client.request('InitiateAuth', jsonReq, function(err, data) {
            if (err) {
                return callback.onFailure(err);
            }
            var challengeName = data.ChallengeName;
            var challengeParameters = data.ChallengeParameters;
            if (challengeName === 'CUSTOM_CHALLENGE') {
                _this.Session = data.Session;
                return callback.customChallenge(challengeParameters);
            }
            _this.signInUserSession = _this.getCognitoUserSession(data.AuthenticationResult);
            _this.cacheTokens();
            return callback.onSuccess(_this.signInUserSession);
        });
    };
    _proto.authenticateUser = function authenticateUser(authDetails, callback) {
        if (this.authenticationFlowType === 'USER_PASSWORD_AUTH') {
            return this.authenticateUserPlainUsernamePassword(authDetails, callback);
        } else if (this.authenticationFlowType === 'USER_SRP_AUTH' || this.authenticationFlowType === 'CUSTOM_AUTH') {
            return this.authenticateUserDefaultAuth(authDetails, callback);
        }
        return callback.onFailure(new Error('Authentication flow type is invalid.'));
    };
    _proto.authenticateUserDefaultAuth = function authenticateUserDefaultAuth(authDetails, callback) {
        var _this2 = this;
        var authenticationHelper = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.pool.getUserPoolName());
        var dateHelper = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$DateHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        var serverBValue;
        var salt;
        var authParameters = {};
        if (this.deviceKey != null) {
            authParameters.DEVICE_KEY = this.deviceKey;
        }
        authParameters.USERNAME = this.username;
        authenticationHelper.getLargeAValue(function(errOnAValue, aValue) {
            // getLargeAValue callback start
            if (errOnAValue) {
                callback.onFailure(errOnAValue);
            }
            authParameters.SRP_A = aValue.toString(16);
            if (_this2.authenticationFlowType === 'CUSTOM_AUTH') {
                authParameters.CHALLENGE_NAME = 'SRP_A';
            }
            var clientMetaData = Object.keys(authDetails.getValidationData()).length !== 0 ? authDetails.getValidationData() : authDetails.getClientMetadata();
            var jsonReq = {
                AuthFlow: _this2.authenticationFlowType,
                ClientId: _this2.pool.getClientId(),
                AuthParameters: authParameters,
                ClientMetadata: clientMetaData
            };
            if (_this2.getUserContextData(_this2.username)) {
                jsonReq.UserContextData = _this2.getUserContextData(_this2.username);
            }
            _this2.client.request('InitiateAuth', jsonReq, function(err, data) {
                if (err) {
                    return callback.onFailure(err);
                }
                var challengeParameters = data.ChallengeParameters;
                _this2.username = challengeParameters.USER_ID_FOR_SRP;
                _this2.userDataKey = _this2.keyPrefix + "." + _this2.username + ".userData";
                serverBValue = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](challengeParameters.SRP_B, 16);
                salt = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](challengeParameters.SALT, 16);
                _this2.getCachedDeviceKeyAndPassword();
                authenticationHelper.getPasswordAuthenticationKey(_this2.username, authDetails.getPassword(), serverBValue, salt, function(errOnHkdf, hkdf) {
                    // getPasswordAuthenticationKey callback start
                    if (errOnHkdf) {
                        callback.onFailure(errOnHkdf);
                    }
                    var dateNow = dateHelper.getNowString();
                    var concatBuffer = __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].concat([
                        __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(_this2.pool.getUserPoolName(), 'utf8'),
                        __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(_this2.username, 'utf8'),
                        __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(challengeParameters.SECRET_BLOCK, 'base64'),
                        __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(dateNow, 'utf8')
                    ]);
                    var awsCryptoHash = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$node_modules$2f40$aws$2d$crypto$2f$sha256$2d$js$2f$build$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Sha256"](hkdf);
                    awsCryptoHash.update(concatBuffer);
                    var resultFromAWSCrypto = awsCryptoHash.digestSync();
                    var signatureString = __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(resultFromAWSCrypto).toString('base64');
                    var challengeResponses = {};
                    challengeResponses.USERNAME = _this2.username;
                    challengeResponses.PASSWORD_CLAIM_SECRET_BLOCK = challengeParameters.SECRET_BLOCK;
                    challengeResponses.TIMESTAMP = dateNow;
                    challengeResponses.PASSWORD_CLAIM_SIGNATURE = signatureString;
                    if (_this2.deviceKey != null) {
                        challengeResponses.DEVICE_KEY = _this2.deviceKey;
                    }
                    var _respondToAuthChallenge = function respondToAuthChallenge(challenge, challengeCallback) {
                        return _this2.client.request('RespondToAuthChallenge', challenge, function(errChallenge, dataChallenge) {
                            if (errChallenge && errChallenge.code === 'ResourceNotFoundException' && errChallenge.message.toLowerCase().indexOf('device') !== -1) {
                                challengeResponses.DEVICE_KEY = null;
                                _this2.deviceKey = null;
                                _this2.randomPassword = null;
                                _this2.deviceGroupKey = null;
                                _this2.clearCachedDeviceKeyAndPassword();
                                return _respondToAuthChallenge(challenge, challengeCallback);
                            }
                            return challengeCallback(errChallenge, dataChallenge);
                        });
                    };
                    var jsonReqResp = {
                        ChallengeName: 'PASSWORD_VERIFIER',
                        ClientId: _this2.pool.getClientId(),
                        ChallengeResponses: challengeResponses,
                        Session: data.Session,
                        ClientMetadata: clientMetaData
                    };
                    if (_this2.getUserContextData()) {
                        jsonReqResp.UserContextData = _this2.getUserContextData();
                    }
                    _respondToAuthChallenge(jsonReqResp, function(errAuthenticate, dataAuthenticate) {
                        if (errAuthenticate) {
                            return callback.onFailure(errAuthenticate);
                        }
                        return _this2.authenticateUserInternal(dataAuthenticate, authenticationHelper, callback);
                    });
                    return undefined;
                // getPasswordAuthenticationKey callback end
                });
                return undefined;
            });
        // getLargeAValue callback end
        });
    };
    _proto.authenticateUserPlainUsernamePassword = function authenticateUserPlainUsernamePassword(authDetails, callback) {
        var _this3 = this;
        var authParameters = {};
        authParameters.USERNAME = this.username;
        authParameters.PASSWORD = authDetails.getPassword();
        if (!authParameters.PASSWORD) {
            callback.onFailure(new Error('PASSWORD parameter is required'));
            return;
        }
        var authenticationHelper = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.pool.getUserPoolName());
        this.getCachedDeviceKeyAndPassword();
        if (this.deviceKey != null) {
            authParameters.DEVICE_KEY = this.deviceKey;
        }
        var clientMetaData = Object.keys(authDetails.getValidationData()).length !== 0 ? authDetails.getValidationData() : authDetails.getClientMetadata();
        var jsonReq = {
            AuthFlow: 'USER_PASSWORD_AUTH',
            ClientId: this.pool.getClientId(),
            AuthParameters: authParameters,
            ClientMetadata: clientMetaData
        };
        if (this.getUserContextData(this.username)) {
            jsonReq.UserContextData = this.getUserContextData(this.username);
        }
        // USER_PASSWORD_AUTH happens in a single round-trip: client sends userName and password,
        // Cognito UserPools verifies password and returns tokens.
        this.client.request('InitiateAuth', jsonReq, function(err, authResult) {
            if (err) {
                return callback.onFailure(err);
            }
            return _this3.authenticateUserInternal(authResult, authenticationHelper, callback);
        });
    };
    _proto.authenticateUserInternal = function authenticateUserInternal(dataAuthenticate, authenticationHelper, callback) {
        var _this4 = this;
        var challengeName = dataAuthenticate.ChallengeName;
        var challengeParameters = dataAuthenticate.ChallengeParameters;
        if (challengeName === 'SMS_MFA') {
            this.Session = dataAuthenticate.Session;
            return callback.mfaRequired(challengeName, challengeParameters);
        }
        if (challengeName === 'SELECT_MFA_TYPE') {
            this.Session = dataAuthenticate.Session;
            return callback.selectMFAType(challengeName, challengeParameters);
        }
        if (challengeName === 'MFA_SETUP') {
            this.Session = dataAuthenticate.Session;
            return callback.mfaSetup(challengeName, challengeParameters);
        }
        if (challengeName === 'SOFTWARE_TOKEN_MFA') {
            this.Session = dataAuthenticate.Session;
            return callback.totpRequired(challengeName, challengeParameters);
        }
        if (challengeName === 'CUSTOM_CHALLENGE') {
            this.Session = dataAuthenticate.Session;
            return callback.customChallenge(challengeParameters);
        }
        if (challengeName === 'NEW_PASSWORD_REQUIRED') {
            this.Session = dataAuthenticate.Session;
            var userAttributes = null;
            var rawRequiredAttributes = null;
            var requiredAttributes = [];
            var userAttributesPrefix = authenticationHelper.getNewPasswordRequiredChallengeUserAttributePrefix();
            if (challengeParameters) {
                userAttributes = JSON.parse(dataAuthenticate.ChallengeParameters.userAttributes);
                rawRequiredAttributes = JSON.parse(dataAuthenticate.ChallengeParameters.requiredAttributes);
            }
            if (rawRequiredAttributes) {
                for(var i = 0; i < rawRequiredAttributes.length; i++){
                    requiredAttributes[i] = rawRequiredAttributes[i].substr(userAttributesPrefix.length);
                }
            }
            return callback.newPasswordRequired(userAttributes, requiredAttributes);
        }
        if (challengeName === 'DEVICE_SRP_AUTH') {
            this.Session = dataAuthenticate.Session;
            this.getDeviceResponse(callback);
            return undefined;
        }
        this.signInUserSession = this.getCognitoUserSession(dataAuthenticate.AuthenticationResult);
        this.challengeName = challengeName;
        this.cacheTokens();
        var newDeviceMetadata = dataAuthenticate.AuthenticationResult.NewDeviceMetadata;
        if (newDeviceMetadata == null) {
            return callback.onSuccess(this.signInUserSession);
        }
        authenticationHelper.generateHashDevice(dataAuthenticate.AuthenticationResult.NewDeviceMetadata.DeviceGroupKey, dataAuthenticate.AuthenticationResult.NewDeviceMetadata.DeviceKey, function(errGenHash) {
            if (errGenHash) {
                return callback.onFailure(errGenHash);
            }
            var deviceSecretVerifierConfig = {
                Salt: __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(authenticationHelper.getSaltDevices(), 'hex').toString('base64'),
                PasswordVerifier: __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(authenticationHelper.getVerifierDevices(), 'hex').toString('base64')
            };
            _this4.verifierDevices = deviceSecretVerifierConfig.PasswordVerifier;
            _this4.deviceGroupKey = newDeviceMetadata.DeviceGroupKey;
            _this4.randomPassword = authenticationHelper.getRandomPassword();
            _this4.client.request('ConfirmDevice', {
                DeviceKey: newDeviceMetadata.DeviceKey,
                AccessToken: _this4.signInUserSession.getAccessToken().getJwtToken(),
                DeviceSecretVerifierConfig: deviceSecretVerifierConfig,
                DeviceName: userAgent
            }, function(errConfirm, dataConfirm) {
                if (errConfirm) {
                    return callback.onFailure(errConfirm);
                }
                _this4.deviceKey = dataAuthenticate.AuthenticationResult.NewDeviceMetadata.DeviceKey;
                _this4.cacheDeviceKeyAndPassword();
                if (dataConfirm.UserConfirmationNecessary === true) {
                    return callback.onSuccess(_this4.signInUserSession, dataConfirm.UserConfirmationNecessary);
                }
                return callback.onSuccess(_this4.signInUserSession);
            });
            return undefined;
        });
        return undefined;
    };
    _proto.completeNewPasswordChallenge = function completeNewPasswordChallenge(newPassword, requiredAttributeData, callback, clientMetadata) {
        var _this5 = this;
        if (!newPassword) {
            return callback.onFailure(new Error('New password is required.'));
        }
        var authenticationHelper = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.pool.getUserPoolName());
        var userAttributesPrefix = authenticationHelper.getNewPasswordRequiredChallengeUserAttributePrefix();
        var finalUserAttributes = {};
        if (requiredAttributeData) {
            Object.keys(requiredAttributeData).forEach(function(key) {
                finalUserAttributes[userAttributesPrefix + key] = requiredAttributeData[key];
            });
        }
        finalUserAttributes.NEW_PASSWORD = newPassword;
        finalUserAttributes.USERNAME = this.username;
        var jsonReq = {
            ChallengeName: 'NEW_PASSWORD_REQUIRED',
            ClientId: this.pool.getClientId(),
            ChallengeResponses: finalUserAttributes,
            Session: this.Session,
            ClientMetadata: clientMetadata
        };
        if (this.getUserContextData()) {
            jsonReq.UserContextData = this.getUserContextData();
        }
        this.client.request('RespondToAuthChallenge', jsonReq, function(errAuthenticate, dataAuthenticate) {
            if (errAuthenticate) {
                return callback.onFailure(errAuthenticate);
            }
            return _this5.authenticateUserInternal(dataAuthenticate, authenticationHelper, callback);
        });
        return undefined;
    };
    _proto.getDeviceResponse = function getDeviceResponse(callback, clientMetadata) {
        var _this6 = this;
        var authenticationHelper = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.deviceGroupKey);
        var dateHelper = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$DateHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        var authParameters = {};
        authParameters.USERNAME = this.username;
        authParameters.DEVICE_KEY = this.deviceKey;
        authenticationHelper.getLargeAValue(function(errAValue, aValue) {
            // getLargeAValue callback start
            if (errAValue) {
                callback.onFailure(errAValue);
            }
            authParameters.SRP_A = aValue.toString(16);
            var jsonReq = {
                ChallengeName: 'DEVICE_SRP_AUTH',
                ClientId: _this6.pool.getClientId(),
                ChallengeResponses: authParameters,
                ClientMetadata: clientMetadata,
                Session: _this6.Session
            };
            if (_this6.getUserContextData()) {
                jsonReq.UserContextData = _this6.getUserContextData();
            }
            _this6.client.request('RespondToAuthChallenge', jsonReq, function(err, data) {
                if (err) {
                    return callback.onFailure(err);
                }
                var challengeParameters = data.ChallengeParameters;
                var serverBValue = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](challengeParameters.SRP_B, 16);
                var salt = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$BigInteger$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](challengeParameters.SALT, 16);
                authenticationHelper.getPasswordAuthenticationKey(_this6.deviceKey, _this6.randomPassword, serverBValue, salt, function(errHkdf, hkdf) {
                    // getPasswordAuthenticationKey callback start
                    if (errHkdf) {
                        return callback.onFailure(errHkdf);
                    }
                    var dateNow = dateHelper.getNowString();
                    var concatBuffer = __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].concat([
                        __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(_this6.deviceGroupKey, 'utf8'),
                        __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(_this6.deviceKey, 'utf8'),
                        __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(challengeParameters.SECRET_BLOCK, 'base64'),
                        __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(dateNow, 'utf8')
                    ]);
                    var awsCryptoHash = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$node_modules$2f40$aws$2d$crypto$2f$sha256$2d$js$2f$build$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Sha256"](hkdf);
                    awsCryptoHash.update(concatBuffer);
                    var resultFromAWSCrypto = awsCryptoHash.digestSync();
                    var signatureString = __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(resultFromAWSCrypto).toString('base64');
                    var challengeResponses = {};
                    challengeResponses.USERNAME = _this6.username;
                    challengeResponses.PASSWORD_CLAIM_SECRET_BLOCK = challengeParameters.SECRET_BLOCK;
                    challengeResponses.TIMESTAMP = dateNow;
                    challengeResponses.PASSWORD_CLAIM_SIGNATURE = signatureString;
                    challengeResponses.DEVICE_KEY = _this6.deviceKey;
                    var jsonReqResp = {
                        ChallengeName: 'DEVICE_PASSWORD_VERIFIER',
                        ClientId: _this6.pool.getClientId(),
                        ChallengeResponses: challengeResponses,
                        Session: data.Session
                    };
                    if (_this6.getUserContextData()) {
                        jsonReqResp.UserContextData = _this6.getUserContextData();
                    }
                    _this6.client.request('RespondToAuthChallenge', jsonReqResp, function(errAuthenticate, dataAuthenticate) {
                        if (errAuthenticate) {
                            return callback.onFailure(errAuthenticate);
                        }
                        _this6.signInUserSession = _this6.getCognitoUserSession(dataAuthenticate.AuthenticationResult);
                        _this6.cacheTokens();
                        return callback.onSuccess(_this6.signInUserSession);
                    });
                    return undefined;
                // getPasswordAuthenticationKey callback end
                });
                return undefined;
            });
        // getLargeAValue callback end
        });
    };
    _proto.confirmRegistration = function confirmRegistration(confirmationCode, forceAliasCreation, callback, clientMetadata) {
        var jsonReq = {
            ClientId: this.pool.getClientId(),
            ConfirmationCode: confirmationCode,
            Username: this.username,
            ForceAliasCreation: forceAliasCreation,
            ClientMetadata: clientMetadata
        };
        if (this.getUserContextData()) {
            jsonReq.UserContextData = this.getUserContextData();
        }
        this.client.request('ConfirmSignUp', jsonReq, function(err) {
            if (err) {
                return callback(err, null);
            }
            return callback(null, 'SUCCESS');
        });
    };
    _proto.sendCustomChallengeAnswer = function sendCustomChallengeAnswer(answerChallenge, callback, clientMetadata) {
        var _this7 = this;
        var challengeResponses = {};
        challengeResponses.USERNAME = this.username;
        challengeResponses.ANSWER = answerChallenge;
        var authenticationHelper = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.pool.getUserPoolName());
        this.getCachedDeviceKeyAndPassword();
        if (this.deviceKey != null) {
            challengeResponses.DEVICE_KEY = this.deviceKey;
        }
        var jsonReq = {
            ChallengeName: 'CUSTOM_CHALLENGE',
            ChallengeResponses: challengeResponses,
            ClientId: this.pool.getClientId(),
            Session: this.Session,
            ClientMetadata: clientMetadata
        };
        if (this.getUserContextData()) {
            jsonReq.UserContextData = this.getUserContextData();
        }
        this.client.request('RespondToAuthChallenge', jsonReq, function(err, data) {
            if (err) {
                return callback.onFailure(err);
            }
            return _this7.authenticateUserInternal(data, authenticationHelper, callback);
        });
    };
    _proto.sendMFACode = function sendMFACode(confirmationCode, callback, mfaType, clientMetadata) {
        var _this8 = this;
        var challengeResponses = {};
        challengeResponses.USERNAME = this.username;
        challengeResponses.SMS_MFA_CODE = confirmationCode;
        var mfaTypeSelection = mfaType || 'SMS_MFA';
        if (mfaTypeSelection === 'SOFTWARE_TOKEN_MFA') {
            challengeResponses.SOFTWARE_TOKEN_MFA_CODE = confirmationCode;
        }
        if (this.deviceKey != null) {
            challengeResponses.DEVICE_KEY = this.deviceKey;
        }
        var jsonReq = {
            ChallengeName: mfaTypeSelection,
            ChallengeResponses: challengeResponses,
            ClientId: this.pool.getClientId(),
            Session: this.Session,
            ClientMetadata: clientMetadata
        };
        if (this.getUserContextData()) {
            jsonReq.UserContextData = this.getUserContextData();
        }
        this.client.request('RespondToAuthChallenge', jsonReq, function(err, dataAuthenticate) {
            if (err) {
                return callback.onFailure(err);
            }
            var challengeName = dataAuthenticate.ChallengeName;
            if (challengeName === 'DEVICE_SRP_AUTH') {
                _this8.getDeviceResponse(callback);
                return undefined;
            }
            _this8.signInUserSession = _this8.getCognitoUserSession(dataAuthenticate.AuthenticationResult);
            _this8.cacheTokens();
            if (dataAuthenticate.AuthenticationResult.NewDeviceMetadata == null) {
                return callback.onSuccess(_this8.signInUserSession);
            }
            var authenticationHelper = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](_this8.pool.getUserPoolName());
            authenticationHelper.generateHashDevice(dataAuthenticate.AuthenticationResult.NewDeviceMetadata.DeviceGroupKey, dataAuthenticate.AuthenticationResult.NewDeviceMetadata.DeviceKey, function(errGenHash) {
                if (errGenHash) {
                    return callback.onFailure(errGenHash);
                }
                var deviceSecretVerifierConfig = {
                    Salt: __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(authenticationHelper.getSaltDevices(), 'hex').toString('base64'),
                    PasswordVerifier: __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(authenticationHelper.getVerifierDevices(), 'hex').toString('base64')
                };
                _this8.verifierDevices = deviceSecretVerifierConfig.PasswordVerifier;
                _this8.deviceGroupKey = dataAuthenticate.AuthenticationResult.NewDeviceMetadata.DeviceGroupKey;
                _this8.randomPassword = authenticationHelper.getRandomPassword();
                _this8.client.request('ConfirmDevice', {
                    DeviceKey: dataAuthenticate.AuthenticationResult.NewDeviceMetadata.DeviceKey,
                    AccessToken: _this8.signInUserSession.getAccessToken().getJwtToken(),
                    DeviceSecretVerifierConfig: deviceSecretVerifierConfig,
                    DeviceName: userAgent
                }, function(errConfirm, dataConfirm) {
                    if (errConfirm) {
                        return callback.onFailure(errConfirm);
                    }
                    _this8.deviceKey = dataAuthenticate.AuthenticationResult.NewDeviceMetadata.DeviceKey;
                    _this8.cacheDeviceKeyAndPassword();
                    if (dataConfirm.UserConfirmationNecessary === true) {
                        return callback.onSuccess(_this8.signInUserSession, dataConfirm.UserConfirmationNecessary);
                    }
                    return callback.onSuccess(_this8.signInUserSession);
                });
                return undefined;
            });
            return undefined;
        });
    };
    _proto.changePassword = function changePassword(oldUserPassword, newUserPassword, callback, clientMetadata) {
        if (!(this.signInUserSession != null && this.signInUserSession.isValid())) {
            return callback(new Error('User is not authenticated'), null);
        }
        this.client.request('ChangePassword', {
            PreviousPassword: oldUserPassword,
            ProposedPassword: newUserPassword,
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken(),
            ClientMetadata: clientMetadata
        }, function(err) {
            if (err) {
                return callback(err, null);
            }
            return callback(null, 'SUCCESS');
        });
        return undefined;
    };
    _proto.enableMFA = function enableMFA(callback) {
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback(new Error('User is not authenticated'), null);
        }
        var mfaOptions = [];
        var mfaEnabled = {
            DeliveryMedium: 'SMS',
            AttributeName: 'phone_number'
        };
        mfaOptions.push(mfaEnabled);
        this.client.request('SetUserSettings', {
            MFAOptions: mfaOptions,
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken()
        }, function(err) {
            if (err) {
                return callback(err, null);
            }
            return callback(null, 'SUCCESS');
        });
        return undefined;
    };
    _proto.setUserMfaPreference = function setUserMfaPreference(smsMfaSettings, softwareTokenMfaSettings, callback) {
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback(new Error('User is not authenticated'), null);
        }
        this.client.request('SetUserMFAPreference', {
            SMSMfaSettings: smsMfaSettings,
            SoftwareTokenMfaSettings: softwareTokenMfaSettings,
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken()
        }, function(err) {
            if (err) {
                return callback(err, null);
            }
            return callback(null, 'SUCCESS');
        });
        return undefined;
    };
    _proto.disableMFA = function disableMFA(callback) {
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback(new Error('User is not authenticated'), null);
        }
        var mfaOptions = [];
        this.client.request('SetUserSettings', {
            MFAOptions: mfaOptions,
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken()
        }, function(err) {
            if (err) {
                return callback(err, null);
            }
            return callback(null, 'SUCCESS');
        });
        return undefined;
    };
    _proto.deleteUser = function deleteUser(callback, clientMetadata) {
        var _this9 = this;
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback(new Error('User is not authenticated'), null);
        }
        this.client.request('DeleteUser', {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken(),
            ClientMetadata: clientMetadata
        }, function(err) {
            if (err) {
                return callback(err, null);
            }
            _this9.clearCachedUser();
            return callback(null, 'SUCCESS');
        });
        return undefined;
    };
    _proto.updateAttributes = function updateAttributes(attributes, callback, clientMetadata) {
        var _this10 = this;
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback(new Error('User is not authenticated'), null);
        }
        this.client.request('UpdateUserAttributes', {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken(),
            UserAttributes: attributes,
            ClientMetadata: clientMetadata
        }, function(err, result) {
            if (err) {
                return callback(err, null);
            }
            // update cached user
            return _this10.getUserData(function() {
                return callback(null, 'SUCCESS', result);
            }, {
                bypassCache: true
            });
        });
        return undefined;
    };
    _proto.getUserAttributes = function getUserAttributes(callback) {
        if (!(this.signInUserSession != null && this.signInUserSession.isValid())) {
            return callback(new Error('User is not authenticated'), null);
        }
        this.client.request('GetUser', {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken()
        }, function(err, userData) {
            if (err) {
                return callback(err, null);
            }
            var attributeList = [];
            for(var i = 0; i < userData.UserAttributes.length; i++){
                var attribute = {
                    Name: userData.UserAttributes[i].Name,
                    Value: userData.UserAttributes[i].Value
                };
                var userAttribute = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserAttribute$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](attribute);
                attributeList.push(userAttribute);
            }
            return callback(null, attributeList);
        });
        return undefined;
    };
    _proto.getMFAOptions = function getMFAOptions(callback) {
        if (!(this.signInUserSession != null && this.signInUserSession.isValid())) {
            return callback(new Error('User is not authenticated'), null);
        }
        this.client.request('GetUser', {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken()
        }, function(err, userData) {
            if (err) {
                return callback(err, null);
            }
            return callback(null, userData.MFAOptions);
        });
        return undefined;
    };
    _proto.createGetUserRequest = function createGetUserRequest() {
        return this.client.promisifyRequest('GetUser', {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken()
        });
    };
    _proto.refreshSessionIfPossible = function refreshSessionIfPossible(options) {
        var _this11 = this;
        if (options === void 0) {
            options = {};
        }
        // best effort, if not possible
        return new Promise(function(resolve) {
            var refresh = _this11.signInUserSession.getRefreshToken();
            if (refresh && refresh.getToken()) {
                _this11.refreshSession(refresh, resolve, options.clientMetadata);
            } else {
                resolve();
            }
        });
    };
    _proto.getUserData = function getUserData(callback, params) {
        var _this12 = this;
        if (!(this.signInUserSession != null && this.signInUserSession.isValid())) {
            this.clearCachedUserData();
            return callback(new Error('User is not authenticated'), null);
        }
        var userData = this.getUserDataFromCache();
        if (!userData) {
            this.fetchUserData().then(function(data) {
                callback(null, data);
            })["catch"](callback);
            return;
        }
        if (this.isFetchUserDataAndTokenRequired(params)) {
            this.fetchUserData().then(function(data) {
                return _this12.refreshSessionIfPossible(params).then(function() {
                    return data;
                });
            }).then(function(data) {
                return callback(null, data);
            })["catch"](callback);
            return;
        }
        try {
            callback(null, JSON.parse(userData));
            return;
        } catch (err) {
            this.clearCachedUserData();
            callback(err, null);
            return;
        }
    };
    _proto.getUserDataFromCache = function getUserDataFromCache() {
        var userData = this.storage.getItem(this.userDataKey);
        return userData;
    };
    _proto.isFetchUserDataAndTokenRequired = function isFetchUserDataAndTokenRequired(params) {
        var _ref = params || {}, _ref$bypassCache = _ref.bypassCache, bypassCache = _ref$bypassCache === void 0 ? false : _ref$bypassCache;
        return bypassCache;
    };
    _proto.fetchUserData = function fetchUserData() {
        var _this13 = this;
        return this.createGetUserRequest().then(function(data) {
            _this13.cacheUserData(data);
            return data;
        });
    };
    _proto.deleteAttributes = function deleteAttributes(attributeList, callback) {
        var _this14 = this;
        if (!(this.signInUserSession != null && this.signInUserSession.isValid())) {
            return callback(new Error('User is not authenticated'), null);
        }
        this.client.request('DeleteUserAttributes', {
            UserAttributeNames: attributeList,
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken()
        }, function(err) {
            if (err) {
                return callback(err, null);
            }
            // update cached user
            return _this14.getUserData(function() {
                return callback(null, 'SUCCESS');
            }, {
                bypassCache: true
            });
        });
        return undefined;
    };
    _proto.resendConfirmationCode = function resendConfirmationCode(callback, clientMetadata) {
        var jsonReq = {
            ClientId: this.pool.getClientId(),
            Username: this.username,
            ClientMetadata: clientMetadata
        };
        this.client.request('ResendConfirmationCode', jsonReq, function(err, result) {
            if (err) {
                return callback(err, null);
            }
            return callback(null, result);
        });
    };
    _proto.getSession = function getSession(callback, options) {
        if (options === void 0) {
            options = {};
        }
        if (this.username == null) {
            return callback(new Error('Username is null. Cannot retrieve a new session'), null);
        }
        if (this.signInUserSession != null && this.signInUserSession.isValid()) {
            return callback(null, this.signInUserSession);
        }
        var keyPrefix = "CognitoIdentityServiceProvider." + this.pool.getClientId() + "." + this.username;
        var idTokenKey = keyPrefix + ".idToken";
        var accessTokenKey = keyPrefix + ".accessToken";
        var refreshTokenKey = keyPrefix + ".refreshToken";
        var clockDriftKey = keyPrefix + ".clockDrift";
        if (this.storage.getItem(idTokenKey)) {
            var idToken = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoIdToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
                IdToken: this.storage.getItem(idTokenKey)
            });
            var accessToken = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoAccessToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
                AccessToken: this.storage.getItem(accessTokenKey)
            });
            var refreshToken = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoRefreshToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
                RefreshToken: this.storage.getItem(refreshTokenKey)
            });
            var clockDrift = parseInt(this.storage.getItem(clockDriftKey), 0) || 0;
            var sessionData = {
                IdToken: idToken,
                AccessToken: accessToken,
                RefreshToken: refreshToken,
                ClockDrift: clockDrift
            };
            var cachedSession = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserSession$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](sessionData);
            if (cachedSession.isValid()) {
                this.signInUserSession = cachedSession;
                return callback(null, this.signInUserSession);
            }
            if (!refreshToken.getToken()) {
                return callback(new Error('Cannot retrieve a new session. Please authenticate.'), null);
            }
            this.refreshSession(refreshToken, callback, options.clientMetadata);
        } else {
            callback(new Error('Local storage is missing an ID Token, Please authenticate'), null);
        }
        return undefined;
    };
    _proto.refreshSession = function refreshSession(refreshToken, callback, clientMetadata) {
        var _this15 = this;
        var wrappedCallback = this.pool.wrapRefreshSessionCallback ? this.pool.wrapRefreshSessionCallback(callback) : callback;
        var authParameters = {};
        authParameters.REFRESH_TOKEN = refreshToken.getToken();
        var keyPrefix = "CognitoIdentityServiceProvider." + this.pool.getClientId();
        var lastUserKey = keyPrefix + ".LastAuthUser";
        if (this.storage.getItem(lastUserKey)) {
            this.username = this.storage.getItem(lastUserKey);
            var deviceKeyKey = keyPrefix + "." + this.username + ".deviceKey";
            this.deviceKey = this.storage.getItem(deviceKeyKey);
            authParameters.DEVICE_KEY = this.deviceKey;
        }
        var jsonReq = {
            ClientId: this.pool.getClientId(),
            AuthFlow: 'REFRESH_TOKEN_AUTH',
            AuthParameters: authParameters,
            ClientMetadata: clientMetadata
        };
        if (this.getUserContextData()) {
            jsonReq.UserContextData = this.getUserContextData();
        }
        this.client.requestWithRetry('InitiateAuth', jsonReq, function(err, authResult) {
            if (err) {
                if (err.code === 'NotAuthorizedException') {
                    _this15.clearCachedUser();
                }
                return wrappedCallback(err, null);
            }
            if (authResult) {
                var authenticationResult = authResult.AuthenticationResult;
                if (!Object.prototype.hasOwnProperty.call(authenticationResult, 'RefreshToken')) {
                    authenticationResult.RefreshToken = refreshToken.getToken();
                }
                _this15.signInUserSession = _this15.getCognitoUserSession(authenticationResult);
                _this15.cacheTokens();
                return wrappedCallback(null, _this15.signInUserSession);
            }
            return undefined;
        });
    };
    _proto.cacheTokens = function cacheTokens() {
        var keyPrefix = "CognitoIdentityServiceProvider." + this.pool.getClientId();
        var idTokenKey = keyPrefix + "." + this.username + ".idToken";
        var accessTokenKey = keyPrefix + "." + this.username + ".accessToken";
        var refreshTokenKey = keyPrefix + "." + this.username + ".refreshToken";
        var clockDriftKey = keyPrefix + "." + this.username + ".clockDrift";
        var lastUserKey = keyPrefix + ".LastAuthUser";
        this.storage.setItem(idTokenKey, this.signInUserSession.getIdToken().getJwtToken());
        this.storage.setItem(accessTokenKey, this.signInUserSession.getAccessToken().getJwtToken());
        this.storage.setItem(refreshTokenKey, this.signInUserSession.getRefreshToken().getToken());
        this.storage.setItem(clockDriftKey, "" + this.signInUserSession.getClockDrift());
        this.storage.setItem(lastUserKey, this.username);
    };
    _proto.cacheUserData = function cacheUserData(userData) {
        this.storage.setItem(this.userDataKey, JSON.stringify(userData));
    };
    _proto.clearCachedUserData = function clearCachedUserData() {
        this.storage.removeItem(this.userDataKey);
    };
    _proto.clearCachedUser = function clearCachedUser() {
        this.clearCachedTokens();
        this.clearCachedUserData();
    };
    _proto.cacheDeviceKeyAndPassword = function cacheDeviceKeyAndPassword() {
        var keyPrefix = "CognitoIdentityServiceProvider." + this.pool.getClientId() + "." + this.username;
        var deviceKeyKey = keyPrefix + ".deviceKey";
        var randomPasswordKey = keyPrefix + ".randomPasswordKey";
        var deviceGroupKeyKey = keyPrefix + ".deviceGroupKey";
        this.storage.setItem(deviceKeyKey, this.deviceKey);
        this.storage.setItem(randomPasswordKey, this.randomPassword);
        this.storage.setItem(deviceGroupKeyKey, this.deviceGroupKey);
    };
    _proto.getCachedDeviceKeyAndPassword = function getCachedDeviceKeyAndPassword() {
        var keyPrefix = "CognitoIdentityServiceProvider." + this.pool.getClientId() + "." + this.username;
        var deviceKeyKey = keyPrefix + ".deviceKey";
        var randomPasswordKey = keyPrefix + ".randomPasswordKey";
        var deviceGroupKeyKey = keyPrefix + ".deviceGroupKey";
        if (this.storage.getItem(deviceKeyKey)) {
            this.deviceKey = this.storage.getItem(deviceKeyKey);
            this.randomPassword = this.storage.getItem(randomPasswordKey);
            this.deviceGroupKey = this.storage.getItem(deviceGroupKeyKey);
        }
    };
    _proto.clearCachedDeviceKeyAndPassword = function clearCachedDeviceKeyAndPassword() {
        var keyPrefix = "CognitoIdentityServiceProvider." + this.pool.getClientId() + "." + this.username;
        var deviceKeyKey = keyPrefix + ".deviceKey";
        var randomPasswordKey = keyPrefix + ".randomPasswordKey";
        var deviceGroupKeyKey = keyPrefix + ".deviceGroupKey";
        this.storage.removeItem(deviceKeyKey);
        this.storage.removeItem(randomPasswordKey);
        this.storage.removeItem(deviceGroupKeyKey);
    };
    _proto.clearCachedTokens = function clearCachedTokens() {
        var keyPrefix = "CognitoIdentityServiceProvider." + this.pool.getClientId();
        var idTokenKey = keyPrefix + "." + this.username + ".idToken";
        var accessTokenKey = keyPrefix + "." + this.username + ".accessToken";
        var refreshTokenKey = keyPrefix + "." + this.username + ".refreshToken";
        var lastUserKey = keyPrefix + ".LastAuthUser";
        var clockDriftKey = keyPrefix + "." + this.username + ".clockDrift";
        this.storage.removeItem(idTokenKey);
        this.storage.removeItem(accessTokenKey);
        this.storage.removeItem(refreshTokenKey);
        this.storage.removeItem(lastUserKey);
        this.storage.removeItem(clockDriftKey);
    };
    _proto.getCognitoUserSession = function getCognitoUserSession(authResult) {
        var idToken = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoIdToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](authResult);
        var accessToken = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoAccessToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](authResult);
        var refreshToken = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoRefreshToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](authResult);
        var sessionData = {
            IdToken: idToken,
            AccessToken: accessToken,
            RefreshToken: refreshToken
        };
        return new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserSession$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](sessionData);
    };
    _proto.forgotPassword = function forgotPassword(callback, clientMetadata) {
        var jsonReq = {
            ClientId: this.pool.getClientId(),
            Username: this.username,
            ClientMetadata: clientMetadata
        };
        if (this.getUserContextData()) {
            jsonReq.UserContextData = this.getUserContextData();
        }
        this.client.request('ForgotPassword', jsonReq, function(err, data) {
            if (err) {
                return callback.onFailure(err);
            }
            if (typeof callback.inputVerificationCode === 'function') {
                return callback.inputVerificationCode(data);
            }
            return callback.onSuccess(data);
        });
    };
    _proto.confirmPassword = function confirmPassword(confirmationCode, newPassword, callback, clientMetadata) {
        var jsonReq = {
            ClientId: this.pool.getClientId(),
            Username: this.username,
            ConfirmationCode: confirmationCode,
            Password: newPassword,
            ClientMetadata: clientMetadata
        };
        if (this.getUserContextData()) {
            jsonReq.UserContextData = this.getUserContextData();
        }
        this.client.request('ConfirmForgotPassword', jsonReq, function(err) {
            if (err) {
                return callback.onFailure(err);
            }
            return callback.onSuccess('SUCCESS');
        });
    };
    _proto.getAttributeVerificationCode = function getAttributeVerificationCode(attributeName, callback, clientMetadata) {
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback.onFailure(new Error('User is not authenticated'));
        }
        this.client.request('GetUserAttributeVerificationCode', {
            AttributeName: attributeName,
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken(),
            ClientMetadata: clientMetadata
        }, function(err, data) {
            if (err) {
                return callback.onFailure(err);
            }
            if (typeof callback.inputVerificationCode === 'function') {
                return callback.inputVerificationCode(data);
            }
            return callback.onSuccess('SUCCESS');
        });
        return undefined;
    };
    _proto.verifyAttribute = function verifyAttribute(attributeName, confirmationCode, callback) {
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback.onFailure(new Error('User is not authenticated'));
        }
        this.client.request('VerifyUserAttribute', {
            AttributeName: attributeName,
            Code: confirmationCode,
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken()
        }, function(err) {
            if (err) {
                return callback.onFailure(err);
            }
            return callback.onSuccess('SUCCESS');
        });
        return undefined;
    };
    _proto.getDevice = function getDevice(callback) {
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback.onFailure(new Error('User is not authenticated'));
        }
        this.client.request('GetDevice', {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken(),
            DeviceKey: this.deviceKey
        }, function(err, data) {
            if (err) {
                return callback.onFailure(err);
            }
            return callback.onSuccess(data);
        });
        return undefined;
    };
    _proto.forgetSpecificDevice = function forgetSpecificDevice(deviceKey, callback) {
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback.onFailure(new Error('User is not authenticated'));
        }
        this.client.request('ForgetDevice', {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken(),
            DeviceKey: deviceKey
        }, function(err) {
            if (err) {
                return callback.onFailure(err);
            }
            return callback.onSuccess('SUCCESS');
        });
        return undefined;
    };
    _proto.forgetDevice = function forgetDevice(callback) {
        var _this16 = this;
        this.forgetSpecificDevice(this.deviceKey, {
            onFailure: callback.onFailure,
            onSuccess: function onSuccess(result) {
                _this16.deviceKey = null;
                _this16.deviceGroupKey = null;
                _this16.randomPassword = null;
                _this16.clearCachedDeviceKeyAndPassword();
                return callback.onSuccess(result);
            }
        });
    };
    _proto.setDeviceStatusRemembered = function setDeviceStatusRemembered(callback) {
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback.onFailure(new Error('User is not authenticated'));
        }
        this.client.request('UpdateDeviceStatus', {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken(),
            DeviceKey: this.deviceKey,
            DeviceRememberedStatus: 'remembered'
        }, function(err) {
            if (err) {
                return callback.onFailure(err);
            }
            return callback.onSuccess('SUCCESS');
        });
        return undefined;
    };
    _proto.setDeviceStatusNotRemembered = function setDeviceStatusNotRemembered(callback) {
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback.onFailure(new Error('User is not authenticated'));
        }
        this.client.request('UpdateDeviceStatus', {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken(),
            DeviceKey: this.deviceKey,
            DeviceRememberedStatus: 'not_remembered'
        }, function(err) {
            if (err) {
                return callback.onFailure(err);
            }
            return callback.onSuccess('SUCCESS');
        });
        return undefined;
    };
    _proto.listDevices = function listDevices(limit, paginationToken, callback) {
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback.onFailure(new Error('User is not authenticated'));
        }
        var requestParams = {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken(),
            Limit: limit
        };
        if (paginationToken) {
            requestParams.PaginationToken = paginationToken;
        }
        this.client.request('ListDevices', requestParams, function(err, data) {
            if (err) {
                return callback.onFailure(err);
            }
            return callback.onSuccess(data);
        });
        return undefined;
    };
    _proto.globalSignOut = function globalSignOut(callback) {
        var _this17 = this;
        if (this.signInUserSession == null || !this.signInUserSession.isValid()) {
            return callback.onFailure(new Error('User is not authenticated'));
        }
        this.client.request('GlobalSignOut', {
            AccessToken: this.signInUserSession.getAccessToken().getJwtToken()
        }, function(err) {
            if (err) {
                return callback.onFailure(err);
            }
            _this17.clearCachedUser();
            return callback.onSuccess('SUCCESS');
        });
        return undefined;
    };
    _proto.signOut = function signOut(revokeTokenCallback) {
        var _this18 = this;
        // If tokens won't be revoked, we just clean the client data.
        if (!revokeTokenCallback || typeof revokeTokenCallback !== 'function') {
            this.cleanClientData();
            return;
        }
        this.getSession(function(error, _session) {
            if (error) {
                return revokeTokenCallback(error);
            }
            _this18.revokeTokens(function(err) {
                _this18.cleanClientData();
                revokeTokenCallback(err);
            });
        });
    };
    _proto.revokeTokens = function revokeTokens(revokeTokenCallback) {
        if (revokeTokenCallback === void 0) {
            revokeTokenCallback = function revokeTokenCallback() {};
        }
        if (typeof revokeTokenCallback !== 'function') {
            throw new Error('Invalid revokeTokenCallback. It should be a function.');
        }
        var tokensToBeRevoked = [];
        if (!this.signInUserSession) {
            var error = new Error('User is not authenticated');
            return revokeTokenCallback(error);
        }
        if (!this.signInUserSession.getAccessToken()) {
            var _error = new Error('No Access token available');
            return revokeTokenCallback(_error);
        }
        var refreshToken = this.signInUserSession.getRefreshToken().getToken();
        var accessToken = this.signInUserSession.getAccessToken();
        if (this.isSessionRevocable(accessToken)) {
            if (refreshToken) {
                return this.revokeToken({
                    token: refreshToken,
                    callback: revokeTokenCallback
                });
            }
        }
        revokeTokenCallback();
    };
    _proto.isSessionRevocable = function isSessionRevocable(token) {
        if (token && typeof token.decodePayload === 'function') {
            try {
                var _token$decodePayload = token.decodePayload(), origin_jti = _token$decodePayload.origin_jti;
                return !!origin_jti;
            } catch (err) {
            // Nothing to do, token doesnt have origin_jti claim
            }
        }
        return false;
    };
    _proto.cleanClientData = function cleanClientData() {
        this.signInUserSession = null;
        this.clearCachedUser();
    };
    _proto.revokeToken = function revokeToken(_ref2) {
        var token = _ref2.token, callback = _ref2.callback;
        this.client.requestWithRetry('RevokeToken', {
            Token: token,
            ClientId: this.pool.getClientId()
        }, function(err) {
            if (err) {
                return callback(err);
            }
            callback();
        });
    };
    _proto.sendMFASelectionAnswer = function sendMFASelectionAnswer(answerChallenge, callback) {
        var _this19 = this;
        var challengeResponses = {};
        challengeResponses.USERNAME = this.username;
        challengeResponses.ANSWER = answerChallenge;
        var jsonReq = {
            ChallengeName: 'SELECT_MFA_TYPE',
            ChallengeResponses: challengeResponses,
            ClientId: this.pool.getClientId(),
            Session: this.Session
        };
        if (this.getUserContextData()) {
            jsonReq.UserContextData = this.getUserContextData();
        }
        this.client.request('RespondToAuthChallenge', jsonReq, function(err, data) {
            if (err) {
                return callback.onFailure(err);
            }
            _this19.Session = data.Session;
            if (answerChallenge === 'SMS_MFA') {
                return callback.mfaRequired(data.ChallengeName, data.ChallengeParameters);
            }
            if (answerChallenge === 'SOFTWARE_TOKEN_MFA') {
                return callback.totpRequired(data.ChallengeName, data.ChallengeParameters);
            }
            return undefined;
        });
    };
    _proto.getUserContextData = function getUserContextData() {
        var pool = this.pool;
        return pool.getUserContextData(this.username);
    };
    _proto.associateSoftwareToken = function associateSoftwareToken(callback) {
        var _this20 = this;
        if (!(this.signInUserSession != null && this.signInUserSession.isValid())) {
            this.client.request('AssociateSoftwareToken', {
                Session: this.Session
            }, function(err, data) {
                if (err) {
                    return callback.onFailure(err);
                }
                _this20.Session = data.Session;
                return callback.associateSecretCode(data.SecretCode);
            });
        } else {
            this.client.request('AssociateSoftwareToken', {
                AccessToken: this.signInUserSession.getAccessToken().getJwtToken()
            }, function(err, data) {
                if (err) {
                    return callback.onFailure(err);
                }
                return callback.associateSecretCode(data.SecretCode);
            });
        }
    };
    _proto.verifySoftwareToken = function verifySoftwareToken(totpCode, friendlyDeviceName, callback) {
        var _this21 = this;
        if (!(this.signInUserSession != null && this.signInUserSession.isValid())) {
            this.client.request('VerifySoftwareToken', {
                Session: this.Session,
                UserCode: totpCode,
                FriendlyDeviceName: friendlyDeviceName
            }, function(err, data) {
                if (err) {
                    return callback.onFailure(err);
                }
                _this21.Session = data.Session;
                var challengeResponses = {};
                challengeResponses.USERNAME = _this21.username;
                var jsonReq = {
                    ChallengeName: 'MFA_SETUP',
                    ClientId: _this21.pool.getClientId(),
                    ChallengeResponses: challengeResponses,
                    Session: _this21.Session
                };
                if (_this21.getUserContextData()) {
                    jsonReq.UserContextData = _this21.getUserContextData();
                }
                _this21.client.request('RespondToAuthChallenge', jsonReq, function(errRespond, dataRespond) {
                    if (errRespond) {
                        return callback.onFailure(errRespond);
                    }
                    _this21.signInUserSession = _this21.getCognitoUserSession(dataRespond.AuthenticationResult);
                    _this21.cacheTokens();
                    return callback.onSuccess(_this21.signInUserSession);
                });
                return undefined;
            });
        } else {
            this.client.request('VerifySoftwareToken', {
                AccessToken: this.signInUserSession.getAccessToken().getJwtToken(),
                UserCode: totpCode,
                FriendlyDeviceName: friendlyDeviceName
            }, function(err, data) {
                if (err) {
                    return callback.onFailure(err);
                }
                return callback.onSuccess(data);
            });
        }
    };
    return CognitoUser;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/Platform/constants.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AUTH_CATEGORY",
    ()=>AUTH_CATEGORY,
    "FRAMEWORK",
    ()=>FRAMEWORK
]);
var FRAMEWORK = {
    None: '0',
    ReactNative: '1'
};
var AUTH_CATEGORY = 'auth';
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/UserAgent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addAuthCategoryToCognitoUserAgent",
    ()=>addAuthCategoryToCognitoUserAgent,
    "addFrameworkToCognitoUserAgent",
    ()=>addFrameworkToCognitoUserAgent,
    "appendToCognitoUserAgent",
    ()=>appendToCognitoUserAgent,
    "default",
    ()=>__TURBOPACK__default__export__,
    "getAmplifyUserAgent",
    ()=>getAmplifyUserAgent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$Platform$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/Platform/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$Platform$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/Platform/constants.js [app-ssr] (ecmascript)");
;
;
// constructor
function UserAgent() {}
// public
UserAgent.prototype.userAgent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$Platform$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getUserAgent"])();
var appendToCognitoUserAgent = function appendToCognitoUserAgent(content) {
    if (!content) {
        return;
    }
    if (UserAgent.prototype.userAgent && !UserAgent.prototype.userAgent.includes(content)) {
        UserAgent.prototype.userAgent = UserAgent.prototype.userAgent.concat(' ', content);
    }
    if (!UserAgent.prototype.userAgent || UserAgent.prototype.userAgent === '') {
        UserAgent.prototype.userAgent = content;
    }
};
var addAuthCategoryToCognitoUserAgent = function addAuthCategoryToCognitoUserAgent() {
    UserAgent.category = __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$Platform$2f$constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AUTH_CATEGORY"];
};
var addFrameworkToCognitoUserAgent = function addFrameworkToCognitoUserAgent(framework) {
    UserAgent.framework = framework;
};
var getAmplifyUserAgent = function getAmplifyUserAgent(action) {
    var uaCategoryAction = UserAgent.category ? " " + UserAgent.category : '';
    var uaFramework = UserAgent.framework ? " framework/" + UserAgent.framework : '';
    var userAgent = "" + UserAgent.prototype.userAgent + uaCategoryAction + uaFramework;
    return userAgent;
};
const __TURBOPACK__default__export__ = UserAgent;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/Client.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Client
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$isomorphic$2d$unfetch$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/isomorphic-unfetch/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$UserAgent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/UserAgent.js [app-ssr] (ecmascript)");
function _inheritsLoose(t, o) {
    t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o);
}
function _wrapNativeSuper(t) {
    var r = "function" == typeof Map ? new Map() : void 0;
    return _wrapNativeSuper = function _wrapNativeSuper(t) {
        if (null === t || !_isNativeFunction(t)) return t;
        if ("function" != typeof t) throw new TypeError("Super expression must either be null or a function");
        if (void 0 !== r) {
            if (r.has(t)) return r.get(t);
            r.set(t, Wrapper);
        }
        function Wrapper() {
            return _construct(t, arguments, _getPrototypeOf(this).constructor);
        }
        return Wrapper.prototype = Object.create(t.prototype, {
            constructor: {
                value: Wrapper,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), _setPrototypeOf(Wrapper, t);
    }, _wrapNativeSuper(t);
}
function _construct(t, e, r) {
    if (_isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments);
    var o = [
        null
    ];
    o.push.apply(o, e);
    var p = new (t.bind.apply(t, o))();
    return r && _setPrototypeOf(p, r.prototype), p;
}
function _isNativeReflectConstruct() {
    try {
        var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (t) {}
    return (_isNativeReflectConstruct = function _isNativeReflectConstruct() {
        return !!t;
    })();
}
function _isNativeFunction(t) {
    try {
        return -1 !== Function.toString.call(t).indexOf("[native code]");
    } catch (n) {
        return "function" == typeof t;
    }
}
function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
        return t.__proto__ = e, t;
    }, _setPrototypeOf(t, e);
}
function _getPrototypeOf(t) {
    return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
        return t.__proto__ || Object.getPrototypeOf(t);
    }, _getPrototypeOf(t);
}
;
;
var CognitoError = /*#__PURE__*/ function(_Error) {
    function CognitoError(message, code, name, statusCode) {
        var _this;
        _this = _Error.call(this, message) || this;
        _this.code = code;
        _this.name = name;
        _this.statusCode = statusCode;
        return _this;
    }
    _inheritsLoose(CognitoError, _Error);
    return CognitoError;
}(/*#__PURE__*/ _wrapNativeSuper(Error));
/** @class */ var Client = /*#__PURE__*/ function() {
    /**
   * Constructs a new AWS Cognito Identity Provider client object
   * @param {string} region AWS region
   * @param {string} endpoint endpoint
   * @param {object} fetchOptions options for fetch API (only credentials is supported)
   */ function Client(region, endpoint, fetchOptions) {
        this.endpoint = endpoint || "https://cognito-idp." + region + ".amazonaws.com/";
        var _ref = fetchOptions || {}, credentials = _ref.credentials;
        this.fetchOptions = credentials ? {
            credentials: credentials
        } : {};
    }
    /**
   * Makes an unauthenticated request on AWS Cognito Identity Provider API
   * using fetch
   * @param {string} operation API operation
   * @param {object} params Input parameters
   * @returns Promise<object>
   */ var _proto = Client.prototype;
    _proto.promisifyRequest = function promisifyRequest(operation, params) {
        var _this2 = this;
        return new Promise(function(resolve, reject) {
            _this2.request(operation, params, function(err, data) {
                if (err) {
                    reject(new CognitoError(err.message, err.code, err.name, err.statusCode));
                } else {
                    resolve(data);
                }
            });
        });
    };
    _proto.requestWithRetry = function requestWithRetry(operation, params, callback) {
        var _this3 = this;
        var MAX_DELAY_IN_MILLIS = 5 * 1000;
        jitteredExponentialRetry(function(p) {
            return new Promise(function(res, rej) {
                _this3.request(operation, p, function(error, result) {
                    if (error) {
                        rej(error);
                    } else {
                        res(result);
                    }
                });
            });
        }, [
            params
        ], MAX_DELAY_IN_MILLIS).then(function(result) {
            return callback(null, result);
        })["catch"](function(error) {
            return callback(error);
        });
    };
    _proto.request = function request(operation, params, callback) {
        var headers = {
            'Content-Type': 'application/x-amz-json-1.1',
            'X-Amz-Target': "AWSCognitoIdentityProviderService." + operation,
            'X-Amz-User-Agent': (0, __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$UserAgent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getAmplifyUserAgent"])(),
            'Cache-Control': 'no-store'
        };
        var options = Object.assign({}, this.fetchOptions, {
            headers: headers,
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(params)
        });
        var response;
        var responseJsonData;
        fetch(this.endpoint, options).then(function(resp) {
            response = resp;
            return resp;
        }, function(err) {
            // If error happens here, the request failed
            // if it is TypeError throw network error
            if (err instanceof TypeError) {
                throw new Error('Network error');
            }
            throw err;
        }).then(function(resp) {
            return resp.json()["catch"](function() {
                return {};
            });
        }).then(function(data) {
            // return parsed body stream
            if (response.ok) return callback(null, data);
            responseJsonData = data;
            // Taken from aws-sdk-js/lib/protocol/json.js
            // eslint-disable-next-line no-underscore-dangle
            var code = (data.__type || data.code).split('#').pop();
            var error = new Error(data.message || data.Message || null);
            error.name = code;
            error.code = code;
            return callback(error);
        })["catch"](function(err) {
            // first check if we have a service error
            if (response && response.headers && response.headers.get('x-amzn-errortype')) {
                try {
                    var code = response.headers.get('x-amzn-errortype').split(':')[0];
                    var error = new Error(response.status ? response.status.toString() : null);
                    error.code = code;
                    error.name = code;
                    error.statusCode = response.status;
                    return callback(error);
                } catch (ex) {
                    return callback(err);
                }
            // otherwise check if error is Network error
            } else if (err instanceof Error && err.message === 'Network error') {
                err.code = 'NetworkError';
            }
            return callback(err);
        });
    };
    return Client;
}();
;
var logger = {
    debug: function debug() {
    // Intentionally blank. This package doesn't have logging
    }
};
/**
 * For now, all errors are retryable.
 */ var NonRetryableError = /*#__PURE__*/ function(_Error2) {
    function NonRetryableError(message) {
        var _this4;
        _this4 = _Error2.call(this, message) || this;
        _this4.nonRetryable = true;
        return _this4;
    }
    _inheritsLoose(NonRetryableError, _Error2);
    return NonRetryableError;
}(/*#__PURE__*/ _wrapNativeSuper(Error));
var isNonRetryableError = function isNonRetryableError(obj) {
    var key = 'nonRetryable';
    return obj && obj[key];
};
function retry(functionToRetry, args, delayFn, attempt) {
    if (attempt === void 0) {
        attempt = 1;
    }
    if (typeof functionToRetry !== 'function') {
        throw Error('functionToRetry must be a function');
    }
    logger.debug(functionToRetry.name + " attempt #" + attempt + " with args: " + JSON.stringify(args));
    return functionToRetry.apply(void 0, args)["catch"](function(err) {
        logger.debug("error on " + functionToRetry.name, err);
        if (isNonRetryableError(err)) {
            logger.debug(functionToRetry.name + " non retryable error", err);
            throw err;
        }
        var retryIn = delayFn(attempt, args, err);
        logger.debug(functionToRetry.name + " retrying in " + retryIn + " ms");
        if (retryIn !== false) {
            return new Promise(function(res) {
                return setTimeout(res, retryIn);
            }).then(function() {
                return retry(functionToRetry, args, delayFn, attempt + 1);
            });
        } else {
            throw err;
        }
    });
}
function jitteredBackoff(maxDelayMs) {
    var BASE_TIME_MS = 100;
    var JITTER_FACTOR = 100;
    return function(attempt) {
        var delay = Math.pow(2, attempt) * BASE_TIME_MS + JITTER_FACTOR * Math.random();
        return delay > maxDelayMs ? false : delay;
    };
}
var MAX_DELAY_MS = 5 * 60 * 1000;
function jitteredExponentialRetry(functionToRetry, args, maxDelayMs) {
    if (maxDelayMs === void 0) {
        maxDelayMs = MAX_DELAY_MS;
    }
    return retry(functionToRetry, args, jitteredBackoff(maxDelayMs));
}
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserPool.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ __turbopack_context__.s([
    "default",
    ()=>CognitoUserPool
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$Client$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/Client.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUser.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$StorageHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/StorageHelper.js [app-ssr] (ecmascript)");
;
;
;
var USER_POOL_ID_MAX_LENGTH = 55;
/** @class */ var CognitoUserPool = /*#__PURE__*/ function() {
    /**
   * Constructs a new CognitoUserPool object
   * @param {object} data Creation options.
   * @param {string} data.UserPoolId Cognito user pool id.
   * @param {string} data.ClientId User pool application client id.
   * @param {string} data.endpoint Optional custom service endpoint.
   * @param {object} data.fetchOptions Optional options for fetch API.
   *        (only credentials option is supported)
   * @param {object} data.Storage Optional storage object.
   * @param {boolean} data.AdvancedSecurityDataCollectionFlag Optional:
   *        boolean flag indicating if the data collection is enabled
   *        to support cognito advanced security features. By default, this
   *        flag is set to true.
   */ function CognitoUserPool(data, wrapRefreshSessionCallback) {
        var _ref = data || {}, UserPoolId = _ref.UserPoolId, ClientId = _ref.ClientId, endpoint = _ref.endpoint, fetchOptions = _ref.fetchOptions, AdvancedSecurityDataCollectionFlag = _ref.AdvancedSecurityDataCollectionFlag;
        if (!UserPoolId || !ClientId) {
            throw new Error('Both UserPoolId and ClientId are required.');
        }
        if (UserPoolId.length > USER_POOL_ID_MAX_LENGTH || !/^[\w-]+_[0-9a-zA-Z]+$/.test(UserPoolId)) {
            throw new Error('Invalid UserPoolId format.');
        }
        var region = UserPoolId.split('_')[0];
        this.userPoolId = UserPoolId;
        this.clientId = ClientId;
        this.client = new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$Client$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](region, endpoint, fetchOptions);
        /**
     * By default, AdvancedSecurityDataCollectionFlag is set to true,
     * if no input value is provided.
     */ this.advancedSecurityDataCollectionFlag = AdvancedSecurityDataCollectionFlag !== false;
        this.storage = data.Storage || new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$StorageHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]().getStorage();
        if (wrapRefreshSessionCallback) {
            this.wrapRefreshSessionCallback = wrapRefreshSessionCallback;
        }
    }
    /**
   * @returns {string} the user pool id
   */ var _proto = CognitoUserPool.prototype;
    _proto.getUserPoolId = function getUserPoolId() {
        return this.userPoolId;
    };
    _proto.getUserPoolName = function getUserPoolName() {
        return this.getUserPoolId().split('_')[1];
    };
    _proto.getClientId = function getClientId() {
        return this.clientId;
    };
    _proto.signUp = function signUp(username, password, userAttributes, validationData, callback, clientMetadata) {
        var _this = this;
        var jsonReq = {
            ClientId: this.clientId,
            Username: username,
            Password: password,
            UserAttributes: userAttributes,
            ValidationData: validationData,
            ClientMetadata: clientMetadata
        };
        if (this.getUserContextData(username)) {
            jsonReq.UserContextData = this.getUserContextData(username);
        }
        this.client.request('SignUp', jsonReq, function(err, data) {
            if (err) {
                return callback(err, null);
            }
            var cognitoUser = {
                Username: username,
                Pool: _this,
                Storage: _this.storage
            };
            var returnData = {
                user: new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](cognitoUser),
                userConfirmed: data.UserConfirmed,
                userSub: data.UserSub,
                codeDeliveryDetails: data.CodeDeliveryDetails
            };
            return callback(null, returnData);
        });
    };
    _proto.getCurrentUser = function getCurrentUser() {
        var lastUserKey = "CognitoIdentityServiceProvider." + this.clientId + ".LastAuthUser";
        var lastAuthUser = this.storage.getItem(lastUserKey);
        if (lastAuthUser) {
            var cognitoUser = {
                Username: lastAuthUser,
                Pool: this,
                Storage: this.storage
            };
            return new __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](cognitoUser);
        }
        return null;
    };
    _proto.getUserContextData = function getUserContextData(username) {
        if (typeof AmazonCognitoAdvancedSecurityData === 'undefined') {
            return undefined;
        }
        /* eslint-disable */ var amazonCognitoAdvancedSecurityDataConst = AmazonCognitoAdvancedSecurityData;
        /* eslint-enable */ if (this.advancedSecurityDataCollectionFlag) {
            var advancedSecurityData = amazonCognitoAdvancedSecurityDataConst.getData(username, this.userPoolId, this.clientId);
            if (advancedSecurityData) {
                var userContextData = {
                    EncodedData: advancedSecurityData
                };
                return userContextData;
            }
        }
        return {};
    };
    return CognitoUserPool;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CookieStorage.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CookieStorage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$js$2d$cookie$2f$src$2f$js$2e$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/js-cookie/src/js.cookie.js [app-ssr] (ecmascript)");
;
/** @class */ var CookieStorage = /*#__PURE__*/ function() {
    /**
   * Constructs a new CookieStorage object
   * @param {object} data Creation options.
   * @param {string} data.domain Cookies domain (default: domain of the page
   * 				where the cookie was created, excluding subdomains)
   * @param {string} data.path Cookies path (default: '/')
   * @param {integer} data.expires Cookie expiration (in days, default: 365)
   * @param {boolean} data.secure Cookie secure flag (default: true)
   * @param {string} data.sameSite Cookie request behavior (default: null)
   */ function CookieStorage(data) {
        if (data === void 0) {
            data = {};
        }
        if (data.domain) {
            this.domain = data.domain;
        }
        if (data.path) {
            this.path = data.path;
        } else {
            this.path = '/';
        }
        if (Object.prototype.hasOwnProperty.call(data, 'expires')) {
            this.expires = data.expires;
        } else {
            this.expires = 365;
        }
        if (Object.prototype.hasOwnProperty.call(data, 'secure')) {
            this.secure = data.secure;
        } else {
            this.secure = true;
        }
        if (Object.prototype.hasOwnProperty.call(data, 'sameSite')) {
            if (![
                'strict',
                'lax',
                'none'
            ].includes(data.sameSite)) {
                throw new Error('The sameSite value of cookieStorage must be "lax", "strict" or "none".');
            }
            if (data.sameSite === 'none' && !this.secure) {
                throw new Error('sameSite = None requires the Secure attribute in latest browser versions.');
            }
            this.sameSite = data.sameSite;
        } else {
            this.sameSite = null;
        }
    }
    /**
   * This is used to set a specific item in storage
   * @param {string} key - the key for the item
   * @param {object} value - the value
   * @returns {string} value that was set
   */ var _proto = CookieStorage.prototype;
    _proto.setItem = function setItem(key, value) {
        var options = {
            path: this.path,
            expires: this.expires,
            domain: this.domain,
            secure: this.secure
        };
        if (this.sameSite) {
            options.sameSite = this.sameSite;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$js$2d$cookie$2f$src$2f$js$2e$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["set"](key, value, options);
        return __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$js$2d$cookie$2f$src$2f$js$2e$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["get"](key);
    };
    _proto.getItem = function getItem(key) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$js$2d$cookie$2f$src$2f$js$2e$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["get"](key);
    };
    _proto.removeItem = function removeItem(key) {
        var options = {
            path: this.path,
            expires: this.expires,
            domain: this.domain,
            secure: this.secure
        };
        if (this.sameSite) {
            options.sameSite = this.sameSite;
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$js$2d$cookie$2f$src$2f$js$2e$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["remove"](key, options);
    };
    _proto.clear = function clear() {
        var cookies = __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$js$2d$cookie$2f$src$2f$js$2e$cookie$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["get"]();
        var numKeys = Object.keys(cookies).length;
        for(var index = 0; index < numKeys; ++index){
            this.removeItem(Object.keys(cookies)[index]);
        }
        return {};
    };
    return CookieStorage;
}();
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/*!
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */ __turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationDetails$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/AuthenticationDetails.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/AuthenticationHelper.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoAccessToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoAccessToken.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoIdToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoIdToken.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoRefreshToken$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoRefreshToken.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUser.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserAttribute$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserAttribute.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserPool$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserPool.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserSession$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserSession.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CookieStorage$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CookieStorage.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$DateHelper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/DateHelper.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$UserAgent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/UserAgent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$utils$2f$WordArray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/utils/WordArray.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserPool.js [app-ssr] (ecmascript) <export default as CognitoUserPool>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CognitoUserPool",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserPool$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserPool$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserPool.js [app-ssr] (ecmascript)");
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUser.js [app-ssr] (ecmascript) <export default as CognitoUser>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CognitoUser",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUser.js [app-ssr] (ecmascript)");
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/AuthenticationDetails.js [app-ssr] (ecmascript) <export default as AuthenticationDetails>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthenticationDetails",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationDetails$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$AuthenticationDetails$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/AuthenticationDetails.js [app-ssr] (ecmascript)");
}),
"[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserAttribute.js [app-ssr] (ecmascript) <export default as CognitoUserAttribute>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CognitoUserAttribute",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserAttribute$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$twinklepod$2f$twinklepod$2d$monorepo$2f$node_modules$2f$amazon$2d$cognito$2d$identity$2d$js$2f$es$2f$CognitoUserAttribute$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/twinklepod/twinklepod-monorepo/node_modules/amazon-cognito-identity-js/es/CognitoUserAttribute.js [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=b5b53_amazon-cognito-identity-js_es_fb64eb87._.js.map