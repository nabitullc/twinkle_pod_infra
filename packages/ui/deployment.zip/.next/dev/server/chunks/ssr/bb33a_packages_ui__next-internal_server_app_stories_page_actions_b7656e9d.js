module.exports = [
"[project]/twinklepod/twinklepod-monorepo/packages/ui/.next-internal/server/app/stories/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=bb33a_packages_ui__next-internal_server_app_stories_page_actions_b7656e9d.js.map