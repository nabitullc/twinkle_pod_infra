globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/b5b53_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_605f909f._.js",
    "static/chunks/b5b53_next_dist_compiled_react-dom_cf73a2d2._.js",
    "static/chunks/b5b53_next_dist_compiled_react-server-dom-turbopack_ce64143c._.js",
    "static/chunks/b5b53_next_dist_compiled_next-devtools_index_4baf8617.js",
    "static/chunks/b5b53_next_dist_compiled_d94e2d8a._.js",
    "static/chunks/b5b53_next_dist_client_d1ecf391._.js",
    "static/chunks/b5b53_next_dist_f36b1a7c._.js",
    "static/chunks/b5b53_@swc_helpers_cjs_0a551179._.js",
    "static/chunks/twinklepod_twinklepod-monorepo_packages_ui_a0ff3932._.js",
    "static/chunks/turbopack-twinklepod_twinklepod-monorepo_packages_ui_05779a2b._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];