var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__5dc2acda._.js")
R.c("server/chunks/bb33a_packages_ui__next-internal_server_app_favicon_ico_route_actions_c5975cfc.js")
R.m(10605)
module.exports=R.m(10605).exports
