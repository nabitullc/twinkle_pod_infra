globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d85ea3fd07aa3a30.js",
    "static/chunks/ea6cd1628fb7a085.js",
    "static/chunks/b52ad592764b88d5.js",
    "static/chunks/53520662504e0475.js",
    "static/chunks/82640e8d2cdd6f49.js",
    "static/chunks/turbopack-5d738017efeb01f2.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];