module.exports=[52096,(e,o,d)=>{}];

//# sourceMappingURL=bb33a_packages_ui__next-internal_server_app_favicon_ico_route_actions_c5975cfc.js.map