module.exports=[44649,(a,b,c)=>{}];

//# sourceMappingURL=bb33a_packages_ui__next-internal_server_app_stories_page_actions_b7656e9d.js.map