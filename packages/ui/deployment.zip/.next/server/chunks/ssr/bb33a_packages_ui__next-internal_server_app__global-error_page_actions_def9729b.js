module.exports=[33092,(a,b,c)=>{}];

//# sourceMappingURL=bb33a_packages_ui__next-internal_server_app__global-error_page_actions_def9729b.js.map