module.exports=[38404,(a,b,c)=>{}];

//# sourceMappingURL=bb33a_packages_ui__next-internal_server_app_library_page_actions_d4eb985c.js.map