module.exports=[81159,(a,b,c)=>{}];

//# sourceMappingURL=c7428_twinklepod-monorepo_packages_ui__next-internal_server_app_page_actions_69e4508a.js.map