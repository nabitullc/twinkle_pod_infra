module.exports=[22154,(a,b,c)=>{}];

//# sourceMappingURL=bb33a_packages_ui__next-internal_server_app__not-found_page_actions_c72b61d5.js.map