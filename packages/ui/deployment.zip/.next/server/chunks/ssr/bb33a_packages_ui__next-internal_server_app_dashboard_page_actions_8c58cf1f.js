module.exports=[27837,(a,b,c)=>{}];

//# sourceMappingURL=bb33a_packages_ui__next-internal_server_app_dashboard_page_actions_8c58cf1f.js.map