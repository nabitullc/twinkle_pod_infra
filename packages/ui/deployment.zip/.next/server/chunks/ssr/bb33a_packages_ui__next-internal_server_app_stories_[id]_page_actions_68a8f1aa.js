module.exports=[18200,(a,b,c)=>{}];

//# sourceMappingURL=bb33a_packages_ui__next-internal_server_app_stories_%5Bid%5D_page_actions_68a8f1aa.js.map